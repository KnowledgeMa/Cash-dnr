'use client';
import {useEffect,useState} from 'react';
import QRCode from 'qrcode';
export default function DnrQr({id}:{id:string}){
 const [image,setImage]=useState(''),[error,setError]=useState('');
 useEffect(()=>{let active=true;setImage('');setError('');if(/^\d{10}$/.test(id))QRCode.toDataURL(id,{width:400,margin:4,errorCorrectionLevel:'M'}).then(value=>{if(active)setImage(value)}).catch(()=>{if(active)setError('QR code could not be generated. Copy your DNR ID instead.')});return()=>{active=false}},[id]);
 return <section className="dnr-qr" aria-label="Your Cash DNR ID QR code"><h3>Your Cash DNR QR code</h3>{image&&<><img src={image} alt={`Cash DNR ID ${id} QR code`}/><strong>{id}</strong><p>Scan to copy this 10-digit ID into the recipient or customer field. Always check the account name before approving.</p><a className="text-btn" href={image} download={`cash-dnr-${id}.png`}>Download QR code</a></>}{error&&<p role="alert">{error}</p>}<p className="small-note">Contains only your public DNR ID. Scanning does not approve a transaction.</p></section>;
}
