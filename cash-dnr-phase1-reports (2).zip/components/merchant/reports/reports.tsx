'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {readApiResponse} from '../../../lib/client-response';
import ReportFilters from './report-filters';
import SalesHistory from './sales-history';
import {Filters,Sale,defaultFilters} from './types';
import {demoSales} from './demo';
import {downloadSales,EXPORT_LIMIT} from './download';

// Each block on this screen reads from the same filters. To add a new report later,
// add a component below and give it the same `filters` prop.
export default function MerchantReports({demo}:{demo:boolean}){
 const [filters,setFilters]=useState<Filters>(defaultFilters),[size,setSize]=useState(10),[sales,setSales]=useState<Sale[]>([]),[total,setTotal]=useState(0),[loading,setLoading]=useState(true),[error,setError]=useState(''),[downloading,setDownloading]=useState(false),[notice,setNotice]=useState('');
 const ticket=useRef(0);
 const problem=!filters.from||!filters.to?'Choose both a start and an end date.':filters.to<filters.from?'The end date is before the start date.':'';

 // One loader for the screen and for the download.
 const fetchPage=useCallback(async(offset:number,limit:number)=>{
  if(demo)return demoSales(filters,limit,offset);
  const q=new URLSearchParams({from:filters.from,to:filters.to,status:filters.status,limit:String(limit),offset:String(offset)});
  if(filters.search.trim())q.set('search',filters.search.trim());
  const r=await fetch('/api/merchant/reports?'+q);const d=await readApiResponse(r) as {sales?:Sale[];total?:number;error?:string};
  if(!r.ok)throw new Error(d.error||'Unable to load reports.');
  return {sales:d.sales||[],total:d.total||0};
 },[filters,demo]);

 const load=useCallback(async(append:boolean,offset:number)=>{
  if(problem){setLoading(false);return}
  const mine=++ticket.current;setLoading(true);setError('');
  try{
   const r=await fetchPage(offset,size);if(mine!==ticket.current)return;
   setSales(p=>append?[...p,...r.sales]:r.sales);setTotal(r.total);
  }catch(e){if(mine===ticket.current){setError(e instanceof Error?e.message:'Unable to load reports.');setSales([]);setTotal(0)}}
  finally{if(mine===ticket.current)setLoading(false)}
 },[fetchPage,size,problem]);
 // New filters start again from the first page; typing in search waits a moment.
 useEffect(()=>{const t=setTimeout(()=>{load(false,0)},filters.search?350:0);return()=>clearTimeout(t)},[load,filters.search]);

 async function download(){
  setDownloading(true);setNotice('');
  try{
   const r=await downloadSales(fetchPage,filters.from,filters.to);
   setNotice(r.truncated?`Downloaded the first ${EXPORT_LIMIT.toLocaleString()} sales. Narrow the dates to export the rest.`:`Downloaded ${r.count} sale${r.count===1?'':'s'}.`);
  }catch(e){setNotice(e instanceof Error?e.message:'Download failed. Please try again.')}
  finally{setDownloading(false)}
 }
 return <>
  <div className="greeting"><div><div className="eyebrow">MERCHANT RECORDS</div><h1>Reports<span className="lime-text">.</span></h1><p>Pick your dates, narrow by status or reference, and open any sale to see its notes.</p></div></div>
  <ReportFilters value={filters} onChange={setFilters} problem={problem}/>
  <SalesHistory sales={sales} total={total} loading={loading} error={error} size={size} onSize={setSize} onMore={()=>load(true,sales.length)} onRetry={()=>load(false,0)} onDownload={download} downloading={downloading} canDownload={!problem&&!error&&total>0} notice={notice}/>
 </>;
}
