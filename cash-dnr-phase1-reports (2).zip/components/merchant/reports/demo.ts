import {Filters,Sale,ymd} from './types';
const day=(ago:number,h:number)=>{const d=new Date();d.setDate(d.getDate()-ago);d.setHours(h,15,0,0);return d.toISOString()};
const mk=(i:number,ago:number,h:number,ref:string,amount:number,status:Sale['status'],detail:string,who:string,notes:[string,number][]):Sale=>({id:`00000000-0000-4000-8000-${String(i).padStart(12,'0')}`,sale_reference:ref,amount,payment_type:'cash',status,detail_status:detail,customer_name:who,customer_dnr:'1000000001',created_at:day(ago,h),resolved_at:status==='pending'?null:day(ago,h),occurred_at:day(ago,h),notes:notes.map(([reference,denomination])=>({reference,denomination}))});
const all:Sale[]=[
 mk(1,0,14,'SALE-0112',300,'pending','pending','Alex Morgan',[['TEST-ZA-200-0011',200],['TEST-ZA-100-0007',100]]),
 mk(2,0,9,'SALE-0111',150,'accepted','accepted','Thando Dlamini',[['TEST-ZA-100-0021',100],['TEST-ZA-50-0004',50]]),
 mk(3,1,16,'SALE-0110',80,'accepted','accepted','Alex Morgan',[['TEST-ZA-50-0009',50],['TEST-ZA-20-0013',20],['TEST-ZA-10-0002',10]]),
 mk(4,2,11,'SALE-0109',200,'rejected','declined','Sipho Nkosi',[['TEST-ZA-200-0014',200]]),
 mk(5,3,13,'SALE-0108',500,'accepted','accepted','Thando Dlamini',[['TEST-ZA-200-0017',200],['TEST-ZA-200-0018',200],['TEST-ZA-100-0019',100]]),
 mk(6,5,10,'SALE-0107',60,'rejected','cancelled','Alex Morgan',[['TEST-ZA-50-0031',50],['TEST-ZA-10-0032',10]]),
 mk(7,8,15,'SALE-0106',100,'accepted','accepted','Sipho Nkosi',[['TEST-ZA-100-0033',100]]),
 mk(8,14,12,'SALE-0105',250,'accepted','accepted','Alex Morgan',[['TEST-ZA-200-0034',200],['TEST-ZA-50-0035',50]]),
 mk(9,21,9,'SALE-0104',20,'accepted','accepted','Thando Dlamini',[['TEST-ZA-20-0036',20]]),
 mk(10,40,17,'SALE-0103',400,'accepted','accepted','Sipho Nkosi',[['TEST-ZA-200-0037',200],['TEST-ZA-200-0038',200]]),
];
export function demoSales(f:Filters,limit:number,offset:number){
 const q=f.search.trim().toLowerCase();
 const hit=all.filter(s=>{const d=ymd(new Date(s.occurred_at));return d>=f.from&&d<=f.to&&(f.status==='all'||s.status===f.status)&&(!q||s.sale_reference.toLowerCase().includes(q)||s.id.includes(q)||(s.notes||[]).some(n=>n.reference.toLowerCase().includes(q)))});
 return {sales:hit.slice(offset,offset+limit),total:hit.length};
}
