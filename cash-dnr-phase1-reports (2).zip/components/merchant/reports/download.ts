import {salesToCsv,csvFilename} from '../../../lib/merchant-reports-csv';
import type {Sale} from './types';

export const EXPORT_LIMIT=5000;
// fetchPage(offset, limit) is the same loader the screen uses, so the file always matches the current filters.
export async function downloadSales(fetchPage:(offset:number,limit:number)=>Promise<{sales:Sale[];total:number}>,from:string,to:string){
 const all:Sale[]=[];let total=Infinity;
 while(all.length<total&&all.length<EXPORT_LIMIT){
  const page=await fetchPage(all.length,50);
  total=page.total;
  if(!page.sales.length)break;
  all.push(...page.sales);
 }
 const blob=new Blob([salesToCsv(all)],{type:'text/csv;charset=utf-8'});
 const url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download=csvFilename(from,to);document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),1000);
 return {count:all.length,truncated:total>all.length};
}
