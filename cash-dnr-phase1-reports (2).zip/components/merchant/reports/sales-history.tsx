'use client';
import {useState} from 'react';
import {ChevronDown,Download} from 'lucide-react';
import {Sale,rand,statusLabel,stub,typeLabel,when,clock} from './types';
export const pageSizes=[10,25,50];
function Row({s}:{s:Sale}){
 const [open,setOpen]=useState(false);const d=stub(s.occurred_at);const notes=s.notes||[];
 return <li className={'mr-row '+s.status+(open?' open':'')}>
  <button type="button" className="mr-row-head" aria-expanded={open} aria-controls={'mr-'+s.id} onClick={()=>setOpen(!open)}>
   <span className="mr-stub"><strong>{d.day}</strong><small>{d.month}</small></span>
   <span className="mr-main"><strong>{s.sale_reference}</strong><small>{clock(s.occurred_at)} · {s.customer_name}</small></span>
   <span className={'mr-badge '+s.status}>{statusLabel[s.status]}</span>
   <span className="mr-amount">{rand(s.amount)}</span>
   <ChevronDown className="mr-chev" size={18} aria-hidden="true"/>
  </button>
  {open&&<div className="mr-detail" id={'mr-'+s.id}>
   <dl>
    <div><dt>Date and time</dt><dd>{when(s.occurred_at)}</dd></div>
    <div><dt>Type</dt><dd>{typeLabel[s.payment_type]||s.payment_type}</dd></div>
    <div><dt>Outcome</dt><dd>{s.detail_status==='declined'?'Declined by customer':s.detail_status==='cancelled'?'Cancelled by you':statusLabel[s.status]}</dd></div>
    <div><dt>Customer DNR ID</dt><dd>{s.customer_dnr}</dd></div>
    <div className="wide"><dt>Payment ID</dt><dd className="mono">{s.id}</dd></div>
   </dl>
   <div className="mr-notes"><span className="mr-label">Notes in this sale · {notes.length}</span>
    {notes.length?<ul>{notes.map(n=><li key={n.reference}><b>{rand(n.denomination)}</b><span>{n.reference}</span></li>)}</ul>:<p>No note details recorded.</p>}
   </div>
  </div>}
 </li>;
}
export default function SalesHistory({sales,total,loading,error,size,onSize,onMore,onRetry,onDownload,downloading,canDownload,notice}:{sales:Sale[];total:number;loading:boolean;error:string;size:number;onSize:(n:number)=>void;onMore:()=>void;onRetry:()=>void;onDownload:()=>void;downloading:boolean;canDownload:boolean;notice:string}){
 return <section className="mr-history" aria-label="Sales history">
  <header className="mr-history-head">
   <div><h2>Sales history</h2><p>{loading&&!sales.length?'Loading…':total?`Showing ${sales.length} of ${total}`:'Nothing to show'}</p></div>
   <div className="mr-tools"><label className="mr-size">Show<select value={size} onChange={e=>onSize(Number(e.target.value))}>{pageSizes.map(n=><option key={n} value={n}>{n} at a time</option>)}</select></label><button type="button" className="mr-download" disabled={!canDownload||downloading} onClick={onDownload}><Download size={16}/>{downloading?'Preparing…':'Download CSV'}</button></div>
  </header>
  {notice&&<p className="mr-notice" role="status">{notice}</p>}
  {error?<div className="mr-empty"><strong>Couldn’t load your sales</strong><p>{error}</p><button className="light-btn" onClick={onRetry}>Try again</button></div>
  :!loading&&!sales.length?<div className="mr-empty"><strong>No sales match</strong><p>Try a wider date range, another status, or clear the search.</p></div>
  :<ul className={'mr-list'+(loading?' busy':'')}>{sales.map(s=><Row key={s.id} s={s}/>)}</ul>}
  {!error&&sales.length<total&&<button className="mr-more" disabled={loading} onClick={onMore}>{loading?'Loading…':`Show ${Math.min(size,total-sales.length)} more`}</button>}
 </section>;
}
