export type SaleStatus='accepted'|'pending'|'rejected';
export type Sale={id:string;sale_reference:string;amount:number;payment_type:'cash'|'digital';status:SaleStatus;detail_status:string;customer_name:string;customer_dnr:string;created_at:string;resolved_at?:string|null;occurred_at:string;notes:{reference:string;denomination:number}[]|null};
export type Filters={from:string;to:string;status:'all'|SaleStatus;search:string};
export const statusLabel:Record<SaleStatus,string>={accepted:'Accepted',pending:'Pending',rejected:'Rejected'};
export const typeLabel:Record<string,string>={cash:'Cash notes',digital:'Digital'};
export function ymd(d:Date){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
export function defaultFilters():Filters{return {from:ymd(new Date(Date.now()-29*86400000)),to:ymd(new Date()),status:'all',search:''}}
export const rand=(n:number)=>'R'+n.toLocaleString('en-ZA');
const zone='Africa/Johannesburg';
export function stub(iso:string){const d=new Date(iso);return {day:d.toLocaleDateString('en-ZA',{day:'2-digit',timeZone:zone}),month:d.toLocaleDateString('en-ZA',{month:'short',timeZone:zone}).replace('.','').toUpperCase()}}
export function when(iso:string){return new Date(iso).toLocaleString('en-ZA',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',timeZone:zone})}
export function clock(iso:string){return new Date(iso).toLocaleTimeString('en-ZA',{hour:'2-digit',minute:'2-digit',timeZone:zone})}
