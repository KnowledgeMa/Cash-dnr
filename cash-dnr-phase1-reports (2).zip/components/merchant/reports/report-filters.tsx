'use client';
import {CalendarDays,RotateCcw,Search} from 'lucide-react';
import {Filters,SaleStatus,defaultFilters} from './types';
const statuses:{value:Filters['status'];label:string;tone:string}[]=[
 {value:'all',label:'All',tone:'all'},{value:'accepted',label:'Accepted',tone:'accepted'},{value:'pending',label:'Pending',tone:'pending'},{value:'rejected',label:'Rejected',tone:'rejected'}];
export default function ReportFilters({value,onChange,problem}:{value:Filters;onChange:(f:Filters)=>void;problem:string}){
 const set=(p:Partial<Filters>)=>onChange({...value,...p});
 const pristine=JSON.stringify(value)===JSON.stringify(defaultFilters());
 return <section className="mr-filters" aria-label="Report filters">
  <div className="mr-range">
   <div className="mr-field"><label htmlFor="mr-from">From</label><div className="mr-date"><CalendarDays size={16}/><input id="mr-from" type="date" value={value.from} max={value.to||undefined} onChange={e=>set({from:e.target.value})}/></div></div>
   <span className="mr-range-arrow" aria-hidden="true"/>
   <div className="mr-field"><label htmlFor="mr-to">To</label><div className="mr-date"><CalendarDays size={16}/><input id="mr-to" type="date" value={value.to} min={value.from||undefined} onChange={e=>set({to:e.target.value})}/></div></div>
  </div>
  <div className="mr-field mr-grow"><label htmlFor="mr-search">Find a sale</label><div className="mr-search"><Search size={16}/><input id="mr-search" type="search" maxLength={80} placeholder="Sale reference, payment ID or note reference" value={value.search} onChange={e=>set({search:e.target.value})}/></div></div>
  <div className="mr-field mr-wide"><span className="mr-label" id="mr-status-label">Status</span>
   <div className="mr-seg" role="group" aria-labelledby="mr-status-label">{statuses.map(s=><button key={s.value} type="button" aria-pressed={value.status===s.value} className={'mr-seg-btn '+(value.status===s.value?'on':'')} onClick={()=>set({status:s.value as 'all'|SaleStatus})}><i className={'mr-dot '+s.tone}/>{s.label}</button>)}</div>
  </div>
  {problem&&<p className="mr-problem" role="alert">{problem}</p>}
  {!pristine&&<button type="button" className="mr-reset" onClick={()=>onChange(defaultFilters())}><RotateCcw size={14}/> Reset filters</button>}
 </section>;
}
