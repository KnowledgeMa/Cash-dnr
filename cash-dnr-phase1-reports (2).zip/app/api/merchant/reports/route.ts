import {NextRequest} from 'next/server';
import {identity,upstream,json,session,clearSession} from '../../../../lib/server-auth';
import {validateReportQuery} from '../../../../lib/merchant-reports';
export const dynamic='force-dynamic';
export async function GET(req:NextRequest){
 try{
  const auth=await identity(req);
  if(!auth)return clearSession(json({error:'Please log in again.'},401));
  let q;try{q=validateReportQuery(req.nextUrl.searchParams)}catch(e){return json({error:e instanceof Error?e.message:'Invalid request.'},400)}
  const r=await upstream('/rest/v1/rpc/list_merchant_sales',{method:'POST',headers:{Authorization:`Bearer ${auth.token}`},body:JSON.stringify({p_start:q.start,p_end:q.end,p_status:q.status,p_search:q.search||null,p_limit:q.limit,p_offset:q.offset})});
  if(!r.ok){
   const detail=await r.json().catch(()=>({})) as {message?:string};
   if(detail.message==='Merchant access required')return json({error:'Reports are available to merchant accounts only.'},403);
   return json({error:'Reports are not ready. Apply the merchant reports database update.'},503);
  }
  const response=json(await r.json());
  if(auth.renewed)session(response,auth.renewed);
  return response;
 }catch{return json({error:'Unable to load reports.'},503)}
}
