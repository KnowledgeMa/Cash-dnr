import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Cash DNR | Your cash. A clearer record.', description: 'Cash DNR digital authorisation by KCommercial.' };
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}</body></html>}
