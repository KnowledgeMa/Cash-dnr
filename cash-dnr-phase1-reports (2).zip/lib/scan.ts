import {realReference,testReferencePattern} from './note-identity';
export type ScanReading={references:string[];serials:string[];denominations:number[];confidence:number};
export function parseScan(text:string,confidence=0):ScanReading{
 const normalized=text.toUpperCase().replace(/[–—−]/g,'-').replace(/\s*-\s*/g,'-');
 const references=[...new Set(normalized.match(/\bTEST-[A-Z0-9]+(?:-[A-Z0-9]+)*\b/g)||[])].filter(x=>/^TEST-[A-Z0-9-]{4,40}$/.test(x));
 // Join OCR spaces inside letter/digit serials, retaining every printed character.
 const joined=normalized.replace(/\b([A-Z]{1,3})[ \t]+(\d{6,12})(?:[ \t]+([A-Z]{1,2})\b)?/g,'$1$2$3');
 const spacedLines=normalized.split(/\r?\n/).map(line=>line.replace(/[ \t]/g,'')).filter(line=>/^[A-Z]{1,3}\d{6,12}[A-Z]{0,2}$/.test(line));
 const serials=[...new Set([...spacedLines,...(joined.match(/\b[A-Z0-9]{8,16}\b/g)||[])])].filter(x=>/[A-Z]/.test(x)&&(x.match(/\d/g)||[]).length>=6&&!references.some(r=>r.includes(x))&&!spacedLines.some(full=>full!==x&&full.endsWith(x)));
 const currencyMatches=[...text.toUpperCase().matchAll(/\b(?:R|ZAR)\s*(200|100|50|20|10)\b/g)].map(x=>Number(x[1]));
 const denominations=[...new Set(currencyMatches)];
 return {references,serials,denominations,confidence:Math.max(0,Math.min(100,Number.isFinite(confidence)?confidence:0))};
}
export type SerialPass={text:string;confidence:number;region:string};
export function combineSerialPasses(passes:SerialPass[]){
 const candidates=new Map<string,{serial:string;passes:number;regions:string[];confidence:number}>();
 for(const p of passes)for(const serial of parseScan(p.text,p.confidence).serials){const c=candidates.get(serial)||{serial,passes:0,regions:[],confidence:0};c.passes++;c.regions=[...new Set([...c.regions,p.region])];c.confidence=Math.max(c.confidence,p.confidence);candidates.set(serial,c);}
 return [...candidates.values()].sort((a,b)=>b.regions.length-a.regions.length||b.passes-a.passes||b.confidence-a.confidence);
}
export function validateScanDraft(reference:string,denomination:number){
 const ref=reference.trim().toUpperCase();
 if(![10,20,50,100,200].includes(denomination))throw new Error('Select the denomination after checking the image.');
 return {reference:testReferencePattern.test(ref)?ref:realReference(ref,denomination),denomination};
}
