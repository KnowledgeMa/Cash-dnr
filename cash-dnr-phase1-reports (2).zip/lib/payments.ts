import {isNoteReference} from './note-identity';
import {uuidPattern} from './notes';
export function validatePayment(d:{customerDnr?:unknown;references?:unknown;amount?:unknown;saleReference?:unknown;requestKey?:unknown}){
 if(typeof d.customerDnr!=='string'||!/^\d{10}$/.test(d.customerDnr))throw new Error('Enter the customer’s 10-digit DNR ID.');
 if(typeof d.requestKey!=='string'||!uuidPattern.test(d.requestKey))throw new Error('Invalid request identifier.');
 if(typeof d.amount!=='number'||!Number.isInteger(d.amount)||d.amount<1||d.amount>20000)throw new Error('Enter a whole-rand amount from R1 to R20,000.');
 if(typeof d.saleReference!=='string'||d.saleReference.trim().length<2||d.saleReference.trim().length>80)throw new Error('Enter a sale reference of 2–80 characters.');
 if(!Array.isArray(d.references)||d.references.length<1||d.references.length>100||d.references.some(x=>!isNoteReference(x)))throw new Error('Enter 1–100 complete note record references.');
 const references=(d.references as string[]).map(x=>x.trim().toUpperCase());if(new Set(references).size!==references.length)throw new Error('Each note must appear only once.');
 return {customerDnr:d.customerDnr,references,amount:d.amount,saleReference:d.saleReference.trim(),requestKey:d.requestKey};
}
