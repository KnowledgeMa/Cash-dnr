// Application identifiers and plausibility checks; these do not authenticate cash.
export const testReferencePattern=/^TEST-[A-Z0-9-]{4,40}$/;
export const serialPattern=/^[A-Z]{1,3}[0-9]{6,12}[A-Z]{0,2}$/;
export const noteSeries={mandela_2012:'Mandela series · 2012',centenary_2018:'Mandela centenary · 2018',mandela_2023:'Upgraded Mandela · 2023'} as const;
export function normalizeSerial(value:string){return value.trim().toUpperCase().replace(/[ \t]/g,'');}
export function realReference(serial:string,denomination:number){
 const normalized=normalizeSerial(serial);
 if(!serialPattern.test(normalized))throw new Error('Check the complete serial, including every starting and final letter.');
 if(![10,20,50,100,200].includes(denomination))throw new Error('Choose a valid rand denomination.');
 return `ZAR-${denomination}-${normalized}`;
}
export function isNoteReference(value:unknown):value is string{
 if(typeof value!=='string')return false;
 const ref=value.trim().toUpperCase();
 if(testReferencePattern.test(ref))return true;
 const m=/^ZAR-(10|20|50|100|200)-(.+)$/.exec(ref);
 return !!m&&serialPattern.test(m[2]);
}
export function serialFromReference(ref:string){return ref.replace(/^ZAR-(?:10|20|50|100|200)-/,'');}
