export const roles = ['individual','merchant'] as const;
export function validateRegistration(d:any){
 if(!d || typeof d.name!=='string'||d.name.trim().length<2||d.name.length>80) throw new Error('Enter your name (2–80 characters).');
 if(typeof d.email!=='string'||!/^\S+@\S+\.\S+$/.test(d.email)||d.email.length>254) throw new Error('Enter a valid email address.');
 if(typeof d.password!=='string'||d.password.length<12||d.password.length>128) throw new Error('Use a password of 12–128 characters.');
 if(!roles.includes(d.role)) throw new Error('Choose an individual or merchant account.');
 if(d.role==='merchant'&&(typeof d.business!=='string'||d.business.trim().length<2||d.business.length>100)) throw new Error('Enter your business name.');
 if(d.accepted!==true) throw new Error('Please acknowledge the prototype boundaries.');
 return {name:d.name.trim(),email:d.email.trim().toLowerCase(),password:d.password,role:d.role,business:d.role==='merchant'?d.business.trim():null};
}
export function validateProfile(d:{name?:unknown;business?:unknown}){
 if(typeof d.name!=='string'||d.name.trim().length<2||d.name.trim().length>80)throw new Error('Enter your name (2–80 characters).');
 if(d.business!=null&&(typeof d.business!=='string'||d.business.trim().length<2||d.business.trim().length>100))throw new Error('Enter a valid business name (2–100 characters).');
 return {name:d.name.trim(),business:typeof d.business==='string'?d.business.trim():null};
}
