import type {Sale} from '../components/merchant/reports/types';
const zone='Africa/Johannesburg';
const header=['Date','Time','Sale reference','Customer','Customer DNR ID','Type','Status','Outcome','Amount (R)','Notes (count)','Notes','Payment ID'];

// Spreadsheets run text that starts with = + - @ as a formula, so those cells get a leading apostrophe.
export function csvCell(value:unknown):string{
 let s=value==null?'':String(value);
 if(/^[=+\-@\t\r]/.test(s))s="'"+s;
 return /[",\r\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;
}
const outcome=(s:Sale)=>s.detail_status==='declined'?'Declined by customer':s.detail_status==='cancelled'?'Cancelled by merchant':s.status.charAt(0).toUpperCase()+s.status.slice(1);

export function salesToCsv(sales:Sale[]):string{
 const rows=sales.map(s=>{
  const d=new Date(s.occurred_at),notes=s.notes||[];
  return [
   d.toLocaleDateString('en-CA',{timeZone:zone}),
   d.toLocaleTimeString('en-GB',{timeZone:zone,hour:'2-digit',minute:'2-digit'}),
   s.sale_reference,s.customer_name,s.customer_dnr,s.payment_type==='cash'?'Cash notes':'Digital',
   s.status.charAt(0).toUpperCase()+s.status.slice(1),outcome(s),s.amount,notes.length,
   notes.map(n=>`${n.reference} (R${n.denomination})`).join('; '),s.id
  ].map(csvCell).join(',');
 });
 // BOM so Excel opens it as UTF-8; CRLF line endings are what Excel expects.
 return '﻿'+[header.map(csvCell).join(','),...rows].join('\r\n')+'\r\n';
}
export function csvFilename(from:string,to:string){return `cash-dnr-sales_${from}_to_${to}.csv`}
