export function signupError(code?:string,status?:number){
 if(code==='over_email_send_rate_limit')return 'The confirmation-email sending limit has been reached. Please wait before requesting another email.';
 if(code==='over_request_rate_limit'||status===429)return 'Too many requests. Please wait before trying again.';
 if(code==='email_address_not_authorized')return 'The email service is not configured to send confirmation to this address. Contact the app administrator.';
 if(code==='signup_disabled'||code==='email_provider_disabled')return 'New email accounts are currently disabled. Contact the app administrator.';
 if(code==='weak_password')return 'Choose a stronger password that meets the account password requirements.';
 if(code==='unexpected_failure')return 'The account service could not create the account. The administrator needs to check the authentication logs.';
 return 'Registration could not be completed. Check your details or try logging in if you have already registered.';
}
