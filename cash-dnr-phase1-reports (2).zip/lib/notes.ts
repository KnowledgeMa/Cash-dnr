import {realReference,normalizeSerial,noteSeries} from './note-identity';
export function validateNote(d:{reference?:unknown;denomination?:unknown;requestKey?:unknown}){
 const reference=typeof d.reference==='string'?d.reference.trim().toUpperCase():'';
 if(!/^TEST-[A-Z0-9-]{4,40}$/.test(reference))throw new Error('Use a synthetic reference starting with TEST-, followed by 4–40 letters, numbers or hyphens.');
 if(typeof d.denomination!=='number'||![10,20,50,100,200].includes(d.denomination))throw new Error('Choose a valid rand denomination.');
 if(typeof d.requestKey!=='string'||!uuidPattern.test(d.requestKey))throw new Error('Invalid request identifier.');
 return {reference,denomination:d.denomination,requestKey:d.requestKey};
}
export const uuidPattern=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function validateRealNote(d:{serial?:unknown;denomination?:unknown;series?:unknown;confirmed?:unknown;requestKey?:unknown}){
 if(typeof d.serial!=='string'||typeof d.denomination!=='number')throw new Error('Check the complete serial and denomination.');
 const reference=realReference(d.serial,d.denomination);
 if(typeof d.series!=='string'||!Object.hasOwn(noteSeries,d.series))throw new Error('Select the banknote series after checking the physical note.');
 if(d.confirmed!==true)throw new Error('Confirm you checked the physical note and both printed serials.');
 if(typeof d.requestKey!=='string'||!uuidPattern.test(d.requestKey))throw new Error('Invalid request identifier.');
 return {reference,serial:normalizeSerial(d.serial),denomination:d.denomination,series:d.series,requestKey:d.requestKey,confirmed:true};
}
