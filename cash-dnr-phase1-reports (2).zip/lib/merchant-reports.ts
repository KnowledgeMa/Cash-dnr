export const reportStatuses=['all','accepted','pending','rejected'] as const;
export type ReportStatus=typeof reportStatuses[number];
export const pageSizes=[10,25,50] as const;
export type ReportQuery={start:string;end:string;status:ReportStatus;search:string;limit:number;offset:number};
const dayPattern=/^\d{4}-\d{2}-\d{2}$/;
const maxRangeDays=366;

export function parseDay(value:unknown):Date|null{
 if(typeof value!=='string'||!dayPattern.test(value))return null;
 const d=new Date(value+'T00:00:00.000Z');
 return Number.isNaN(d.getTime())||d.toISOString().slice(0,10)!==value?null:d;
}

// Days are South African calendar days (UTC+2, no daylight saving). "To" is inclusive.
export function dayBounds(from:string,to:string){
 const a=parseDay(from),b=parseDay(to);
 if(!a||!b)throw new Error('Choose a start and an end date.');
 if(b<a)throw new Error('The end date cannot be before the start date.');
 const days=Math.round((b.getTime()-a.getTime())/86400000)+1;
 if(days>maxRangeDays)throw new Error('Choose a range of no more than one year.');
 const offset=2*3600000;
 return {start:new Date(a.getTime()-offset).toISOString(),end:new Date(b.getTime()+86400000-offset).toISOString()};
}

export function validateReportQuery(params:URLSearchParams):ReportQuery{
 const from=params.get('from')||'',to=params.get('to')||'';
 const {start,end}=dayBounds(from,to);
 const status=(params.get('status')||'all') as ReportStatus;
 if(!reportStatuses.includes(status))throw new Error('Choose a valid status.');
 const search=(params.get('search')||'').trim();
 if(search.length>80)throw new Error('Search text is too long.');
 const limit=Number(params.get('limit')||10),offset=Number(params.get('offset')||0);
 if(!(pageSizes as readonly number[]).includes(limit))throw new Error('Choose a valid page size.');
 if(!Number.isInteger(offset)||offset<0||offset>100000)throw new Error('Invalid page.');
 return {start,end,status,search,limit,offset};
}
