import type {Worker} from 'tesseract.js';
import {combineSerialPasses,type SerialPass} from './scan';
export type SerialMode='auto'|'closeup'|'back'|'practice';
export type Crop={left:number;right:number;top:number;bottom:number};
// Layout hints are search windows, not a serial-format or authenticity check.
export async function readSerialImage(w:Worker,img:HTMLImageElement,crop:Crop,mode:SerialMode,onProgress:(s:string)=>void,isCurrent:()=>boolean){
 const source=document.createElement('canvas');source.width=Math.max(1,Math.round(img.width*(crop.right-crop.left)/100));source.height=Math.max(1,Math.round(img.height*(crop.bottom-crop.top)/100));
 source.getContext('2d')!.drawImage(img,img.width*crop.left/100,img.height*crop.top/100,source.width,source.height,0,0,source.width,source.height);
 if(mode==='practice'){await w.setParameters({tessedit_pageseg_mode:'3' as never,tessedit_char_whitelist:''});const {data}=await w.recognize(source);return {text:data.text,confidence:data.confidence,candidates:[]};}
 const regions=mode==='auto'?[{name:'Whole image',x:0,y:0,width:1,height:1,rotations:[0,90,270]}]:mode==='back'?[{name:'Top-right serial',x:.45,y:0,width:.55,height:.28,rotations:[0]},{name:'Left serial',x:0,y:.12,width:.23,height:.88,rotations:[90,270]}]:[{name:'Selected serial',x:0,y:0,width:1,height:1,rotations:source.height>source.width?[90,270]:[0]}];
 const passes:SerialPass[]=[];const total=regions.reduce((n,r)=>n+r.rotations.length*2,0);let step=0;
 for(const r of regions)for(const rotation of r.rotations){
 // Keep detected serial candidates for review; rotate further only if none were found.
 if(mode==='auto'&&rotation!==0){const found=combineSerialPasses(passes);if(found.length>0)break;}
 for(const enhanced of [false,true]){
 if(!isCurrent())throw new Error('Cancelled');onProgress(`Reading serial · pass ${++step} of ${total}`);
 const sw=Math.max(1,Math.round(source.width*r.width)),sh=Math.max(1,Math.round(source.height*r.height));
 const rotated=rotation===90||rotation===270;const scale=mode==='auto'?Math.min(3,1500/(rotated?sh:sw),2400/Math.max(sw,sh)):Math.min(3,1800/(rotated?sh:sw));const rw=Math.max(1,Math.round(sw*scale)),rh=Math.max(1,Math.round(sh*scale));
 const padding=mode==='auto'?0:16;const c=document.createElement('canvas');c.width=(rotated?rh:rw)+padding*2;c.height=(rotated?rw:rh)+padding*2;const ctx=c.getContext('2d',{willReadFrequently:true})!;ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.save();ctx.translate(c.width/2,c.height/2);ctx.rotate(rotation*Math.PI/180);ctx.drawImage(source,source.width*r.x,source.height*r.y,sw,sh,-rw/2,-rh/2,rw,rh);ctx.restore();
 if(enhanced){const p=ctx.getImageData(0,0,c.width,c.height);for(let i=0;i<p.data.length;i+=4){const gray=.299*p.data[i]+.587*p.data[i+1]+.114*p.data[i+2];const v=Math.max(0,Math.min(255,(gray-128)*1.8+128));p.data[i]=p.data[i+1]=p.data[i+2]=v;}ctx.putImageData(p,0,0);}
 await w.setParameters({tessedit_pageseg_mode:(mode==='closeup'?'7':'11') as never,tessedit_char_whitelist:'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',user_defined_dpi:'300'});
 const {data}=await w.recognize(c,{rotateAuto:mode==='closeup'});passes.push({text:data.text,confidence:data.confidence,region:r.name});c.width=c.height=1;
 }}
 const candidates=combineSerialPasses(passes);source.width=source.height=1;
 return {text:passes.map(p=>p.text).join('\n'),confidence:candidates[0]?.confidence||0,candidates};
}
