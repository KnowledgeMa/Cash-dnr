export async function readApiResponse<T>(response:Response):Promise<T>{
 const type=response.headers.get('content-type')||'';
 if(response.redirected||!type.toLowerCase().includes('application/json')){
  throw new Error('Cash DNR could not reach the account service. Refresh the page or open Cash DNR in a full browser tab, then try again.');
 }
 try{return await response.json() as T;}catch{throw new Error('The service returned an incomplete response. Please refresh and try again.');}
}
