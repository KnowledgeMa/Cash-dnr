import {isNoteReference} from './note-identity';
export type SendDraft={reference:string;denomination:number;purpose?:'send'};
export type SendableNote={id:string;reference:string;denomination:number;current_holder:string|null;status:string;reservation_kind?:string};
export function matchScannedNote(notes:SendableNote[],userId:string,draft:SendDraft){
 const reference=draft.reference.trim().toUpperCase();
 if(!isNoteReference(reference))return {error:'Check the complete serial reading before sending.'};
 const matches=notes.filter(n=>n.reference===reference&&n.denomination===draft.denomination&&n.current_holder===userId);
 if(matches.length!==1)return {error:'This reading does not match a note currently recorded to your account. Check every serial character and the denomination, or scan again.'};
 const note=matches[0];
 if(note.status!=='active')return {error:'This note is '+note.status+'. Only active notes can be sent.'};
 if(note.reservation_kind)return {error:'This note is reserved for another transaction. Resolve or cancel that transaction first.'};
 return {note};
}
