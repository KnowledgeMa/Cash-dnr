# Camera handover with sender approval

## Activate

1. Apply `supabase/018_scan_to_send.sql` after 016. It deliberately disables the old unapproved sender RPC, including for old clients. Existing pending transfers and acceptance remain available.
2. Replace the deployed `passkey-approval` Supabase function with `supabase/functions/passkey-approval/index.ts` and redeploy using its existing configuration. Keep manual bearer verification and `verify_jwt=false`; do not expose service keys. The worker now allows the `transfer_send` operation in addition to existing acceptance and payment approvals.
3. Optionally run `019_scan_to_send_permission_test.sql` in the SQL editor. All new users, notes, keys and approvals in that test are fixtures rolled back at the end.
4. Reload the app. The sender must have a passkey enrolled under Account. No session-only fallback is permitted for new sends.

## Phone check

- Individual account: scan the active R20 note, review the complete serial `AR230609778B` and R20, confirm the image, then choose **Send this note**.
- Wallet must show **Matched to your wallet**, `ZAR-20-AR230609778B`, R20. A mismatch, wrong holder, lost/stolen note or reservation blocks sending. It never silently substitutes another note.
- Enter the recipient's full DNR ID. Select **Review recipient** and check the returned name, DNR ID, note and amount.
- Select **Approve & send**. Cancel the device prompt first: no transfer or reservation should be created. Retry and approve using the passkey provider's offered verification method.
- Sender sees Pending. Sender remains holder. Recipient signs in, checks physical receipt and accepts through the existing acceptance flow. Holder and history then change atomically.
- Refresh after a completed send: exactly one outgoing transfer should exist. A network retry of the same approved intent returns the existing result, including after it has been accepted/cancelled; it does not recreate it.

## Security and boundaries

The camera performs local OCR; photos are not submitted to this send API. Exact reference plus denomination must match a currently held record. Server validation repeats holder, status and reservation checks when preparing and committing.

Preparing creates a private immutable five-minute intent containing sender, note, recipient DNR ID and request key. It does not create a transfer or reserve a note. The existing trusted worker verifies a WebAuthn signature with required user verification and produces a one-minute, single-use approval bound to that sender, operation kind and intent ID. Editing the note or recipient requires a new intent and approval. Credentials and intents have no client write access. The old internal transfer RPC has no authenticated execute permission.

The phone or passkey provider selects available biometric/PIN/password verification; the app cannot force Face ID versus fingerprint and never receives biometric templates or device passwords. A Cash DNR login password is not a substitute for passkey approval. With a synced/cross-device passkey, the provider's verification interface may differ.

A sender approval records a request to hand over physical cash. Recipient confirmation still changes the recorded holder. No deposited balance, backed funds, currency authentication or electronic money movement is implemented here.

## Checks

Application tests cover exact matching, omitted prefixes, incorrect denomination, foreign holder, restricted/reserved status, ambiguity and synthetic identifiers. Existing cryptographic tests verify signed assertions and reject wrong origin/challenge, missing user verification, stale counters and modified signatures.

The rollback database test covers enrollment, review identity and idempotency, changed recipient payloads, hidden/immutable intents, legacy/internal RPC bypass, missing/expired proofs, other-account challenges and sends, changed holder/status/reservations after review, one-transfer retry, sender-held pending state, separate recipient approval and expired review. Original regression suites run at their original migration stage, then 018 and 019 run against the upgraded schema. Live phone end-to-end verification is required after the two manual deployment steps above.
