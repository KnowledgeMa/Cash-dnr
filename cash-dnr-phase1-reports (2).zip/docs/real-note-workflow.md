# Controlled real note registration

Apply `supabase/016_real_note_registration.sql` once after migration 014, then refresh Wallet. Until then, real declarations remain disabled and TEST records continue to work. Migration 008 (email scheduling) is unrelated and remains paused.

## User workflow

1. Scan a real note, inspect every character and select its denomination.
2. Choose **Use for registration**. The scan becomes a draft, not a saved declaration.
3. Choose the physical banknote series: Mandela 2012, centenary 2018 or upgraded Mandela 2023. Other series are outside this initial registration scope.
4. Confirm physical possession and that both printed serials, denomination and series have been checked. Submit.
5. The declaration is pending, without a holder. An administrator inspects it and must record a review reason before approving or rejecting it.
6. Approval assigns the submitter as the recorded holder and writes history and audit events. Lookup, transfers, incident reports and merchant payments use the existing account and approval controls.

Only the serial, selected series, denomination and confirmation timestamp are persisted; the scanner does not upload or retain the photograph.

## Identity and duplicates

An application reference is generated as `ZAR-<denomination>-<complete serial>`, for example `ZAR-10-AE90834529A`. Series is stored separately. This is an application identifier, not a claim about a Reserve Bank serial-number namespace.

For this controlled phase, currency plus serial is the conservative collision guard across all supported denominations and series. Changing the denomination or series cannot create another holder record. A repeated serial creates an administrator-only flag containing the attempted details and leaves the existing note unchanged. Legitimate collisions and rejected-note resubmissions require a separate review procedure; this change does not implement flag resolution or reissue records.

Letters, digits and spaces are normalised without replacing characters. The accepted serial expression is a plausibility filter, not an official universal South African banknote format. OCR and human entry can still be wrong. Do not treat registration, review, OCR confidence or a serial match as authentication or evidence of legal ownership.

## Security and checks

The new real-note RPC requires an authenticated account, explicit physical review confirmation, a listed series, a supported denomination and an idempotency key. TEST-only registration cannot bypass these checks. Duplicate requests preserve payload identity and do not add repeated flags or audit events. Direct client table writes remain denied; original row-level privacy and administrator checks remain in force.

Payment requests accept canonical real-note references and retain the same all-or-nothing amount, holder, reservation and passkey checks. Pending or rejected declarations cannot be paid.

`supabase/017_real_note_permission_test.sql` is a rollback-only fixture test for existing individual, merchant and administrator accounts. It tests private pending declarations, forged approval attempts, invalid inputs, duplicate conflicts and retries, review reasons, rejection and a two-note real-reference payment. It does not test physical currency authenticity or fund backing.

Series context: SARB banknotes information at https://www.resbank.co.za/en/home/what-we-do/banknotes-and-coin/Banknotes ; 2018 commemorative announcement at https://www.resbank.co.za/en/home/publications/publication-detail-pages/media-releases/2018/8575 .
