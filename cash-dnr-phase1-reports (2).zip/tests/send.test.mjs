import {test} from 'node:test';import assert from 'node:assert/strict';import {tsUrl} from './helpers/import-ts.mjs';
const {matchScannedNote}=await import(tsUrl(new URL('../lib/send.ts',import.meta.url)));
const note={id:'n1',reference:'ZAR-20-AR230609778B',denomination:20,current_holder:'me',status:'active'};
const draft={reference:note.reference,denomination:20,purpose:'send'};
test('scanned real serial and denomination match the current holder’s exact wallet record',()=>assert.deepEqual(matchScannedNote([note],'me',draft),{note}));
test('a missing prefix, wrong denomination, or another holder never selects another note',()=>{for(const d of [{...draft,reference:'ZAR-20-R230609778B'},{...draft,denomination:10},{...draft,reference:'AR230609778B'}])assert.ok(matchScannedNote([note],'me',d).error);assert.ok(matchScannedNote([note],'someone-else',draft).error)});
test('lost, stolen, pending, rejected and reserved notes cannot be sent',()=>{for(const status of ['lost','stolen','pending','rejected'])assert.ok(matchScannedNote([{...note,status}],'me',draft).error);assert.match(matchScannedNote([{...note,reservation_kind:'payment'}],'me',draft).error,/reserved/)});
test('ambiguous matching records fail closed and synthetic references use the same ownership rule',()=>{assert.ok(matchScannedNote([note,note],'me',draft).error);const synthetic={...note,reference:'TEST-ZA-20-0001'};assert.deepEqual(matchScannedNote([synthetic],'me',{...draft,reference:synthetic.reference}),{note:synthetic})});
