import {test} from 'node:test';import assert from 'node:assert/strict';
import {tsUrl} from './helpers/import-ts.mjs';
const {dayBounds,validateReportQuery}=await import(tsUrl(new URL('../lib/merchant-reports.ts',import.meta.url)));
const q=o=>new URLSearchParams({from:'2026-11-01',to:'2026-11-30',...o});
test('a day starts and ends at South African midnight, end date inclusive',()=>{
 const b=dayBounds('2026-11-24','2026-11-24');
 assert.equal(b.start,'2026-11-23T22:00:00.000Z');assert.equal(b.end,'2026-11-24T22:00:00.000Z');
});
test('rejects missing, impossible and reversed dates',()=>{
 for(const [f,t] of [['','2026-11-01'],['2026-02-30','2026-03-01'],['2026-11-05','2026-11-01'],['11/01/2026','2026-11-02']])assert.throws(()=>dayBounds(f,t));
});
test('rejects ranges over one year but allows exactly one year',()=>{
 assert.doesNotThrow(()=>dayBounds('2026-01-01','2026-12-31'));
 assert.throws(()=>dayBounds('2025-01-01','2026-06-01'),/one year/);
});
test('applies defaults and trims search',()=>{
 const v=validateReportQuery(q({search:'  SALE-1 '}));
 assert.equal(v.status,'all');assert.equal(v.limit,10);assert.equal(v.offset,0);assert.equal(v.search,'SALE-1');
});
test('rejects unknown status, odd page sizes, bad offsets and long search',()=>{
 for(const o of [{status:'declined'},{limit:'500'},{limit:'7'},{offset:'-1'},{offset:'1.5'},{search:'x'.repeat(81)}])assert.throws(()=>validateReportQuery(q(o)));
});
const {salesToCsv,csvCell,csvFilename}=await import(tsUrl(new URL('../lib/merchant-reports-csv.ts',import.meta.url)));
const sale=o=>({id:'p1',sale_reference:'SALE-1',amount:300,payment_type:'cash',status:'accepted',detail_status:'accepted',customer_name:'Alex, "AJ" Morgan',customer_dnr:'1000000001',created_at:'2026-11-24T08:00:00Z',occurred_at:'2026-11-24T08:00:00Z',notes:[{reference:'TEST-A',denomination:200},{reference:'TEST-B',denomination:100}],...o});
test('csv has a header, SA-time date and quoted commas/quotes',()=>{
 const lines=salesToCsv([sale()]).replace('﻿','').trim().split('\r\n');
 assert.equal(lines.length,2);assert.match(lines[0],/^Date,Time,Sale reference/);
 assert.match(lines[1],/^2026-11-24,10:00,SALE-1,"Alex, ""AJ"" Morgan",1000000001,Cash notes,Accepted,Accepted,300,2,TEST-A \(R200\); TEST-B \(R100\),p1$/);
});
test('csv neutralises spreadsheet formulas and handles rejected outcomes',()=>{
 assert.equal(csvCell('=HYPERLINK("x")'),'"\'=HYPERLINK(""x"")"');assert.equal(csvCell('@sum'),"'@sum");assert.equal(csvCell('plain'),'plain');
 assert.match(salesToCsv([sale({status:'rejected',detail_status:'declined',notes:null})]),/Rejected,Declined by customer,300,0,,p1/);
});
test('filename carries the date range',()=>assert.equal(csvFilename('2026-11-01','2026-11-30'),'cash-dnr-sales_2026-11-01_to_2026-11-30.csv'));
