import {test} from 'node:test';import assert from 'node:assert/strict';import ts from 'typescript';import {readFileSync} from 'node:fs';
import {tsUrl} from './helpers/import-ts.mjs';
const {validatePayment}=await import(tsUrl(new URL('../lib/payments.ts',import.meta.url)));
const input={customerDnr:'1234567890',requestKey:'00000000-0000-0000-0000-000000000002',amount:300,saleReference:' SALE-1 ',references:['test-za-200-0001',' TEST-ZA-100-0001 ']};
test('normalizes references and sale identifier',()=>{const d=validatePayment(input);assert.deepEqual(d.references,['TEST-ZA-200-0001','TEST-ZA-100-0001']);assert.equal(d.saleReference,'SALE-1')});
test('rejects duplicate normalized notes',()=>assert.throws(()=>validatePayment({...input,references:['TEST-ABCD','test-abcd']}),/only once/));
test('rejects invalid identifiers, noninteger amounts and arbitrary references',()=>{for(const d of [{...input,customerDnr:'short'},{...input,amount:300.5},{...input,references:['REAL-ABCD']},{...input,references:[]},{...input,requestKey:null}])assert.throws(()=>validatePayment(d))});

test('accepts a canonical real-note record but rejects a raw serial',()=>{assert.deepEqual(validatePayment({...input,amount:10,references:['zar-10-ae90834529a']}).references,['ZAR-10-AE90834529A']);assert.throws(()=>validatePayment({...input,references:['AE90834529A']}));});
