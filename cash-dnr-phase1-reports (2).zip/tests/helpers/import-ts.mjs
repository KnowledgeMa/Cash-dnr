import ts from 'typescript';import {readFileSync} from 'node:fs';
const cache=new Map();
export function tsUrl(url){
 const key=String(url);if(cache.has(key))return cache.get(key);
 let source=readFileSync(url,'utf8');
 source=source.replace(/from\s+(['"])(\.[^'"]+)\1/g,(_,quote,path)=>`from ${JSON.stringify(tsUrl(new URL(path.endsWith('.ts')?path:path+'.ts',url)))}`);
 const result='data:text/javascript;base64,'+Buffer.from(ts.transpile(source,{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022})).toString('base64');cache.set(key,result);return result;
}
