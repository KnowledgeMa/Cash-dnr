import {test} from 'node:test';import assert from 'node:assert/strict';import {generateKeyPairSync,createHash,sign,randomBytes} from 'node:crypto';
import {verifyRegistrationResponse,verifyAuthenticationResponse} from '@simplewebauthn/server';
const origin='https://cash-dnr.tverseinfo.chatgpt.site',rpID=new URL(origin).hostname;
const hash=b=>createHash('sha256').update(b).digest(),b64=b=>Buffer.from(b).toString('base64url');
// Small CBOR fixture encoder: builds authentic browser-format test responses.
function head(major,n){if(n<24)return Buffer.from([(major<<5)|n]);if(n<256)return Buffer.from([(major<<5)|24,n]);return Buffer.from([(major<<5)|25,n>>8,n&255])}
function cbor(x){if(typeof x==='number')return x>=0?head(0,x):head(1,-1-x);if(typeof x==='string'){const b=Buffer.from(x);return Buffer.concat([head(3,b.length),b])}if(Buffer.isBuffer(x)||x instanceof Uint8Array){const b=Buffer.from(x);return Buffer.concat([head(2,b.length),b])}const entries=x instanceof Map?[...x]:Object.entries(x);return Buffer.concat([head(5,entries.length),...entries.flatMap(([k,v])=>[cbor(k),cbor(v)])])}
const {privateKey,publicKey}=generateKeyPairSync('ec',{namedCurve:'prime256v1'}),jwk=publicKey.export({format:'jwk'}),id=randomBytes(32);
const cose=cbor(new Map([[1,2],[3,-7],[-1,1],[-2,Buffer.from(jwk.x,'base64url')],[-3,Buffer.from(jwk.y,'base64url')]]));
const challenge=b64(randomBytes(32));
function client(type,opts={}){return Buffer.from(JSON.stringify({type,challenge:opts.challenge||challenge,origin:opts.origin||origin,crossOrigin:false}))}
function authData(flags,counter){const b=Buffer.alloc(37);hash(rpID).copy(b);b[32]=flags;b.writeUInt32BE(counter,33);return b}
function registration(){const data=client('webauthn.create'),len=Buffer.alloc(2);len.writeUInt16BE(id.length);const auth=Buffer.concat([authData(0x45,0),Buffer.alloc(16),len,id,cose]);return {id:b64(id),rawId:b64(id),type:'public-key',clientExtensionResults:{},authenticatorAttachment:'platform',response:{clientDataJSON:b64(data),attestationObject:b64(cbor({fmt:'none',attStmt:{},authData:auth})),transports:['internal']}}}
function assertion(opts={}){const data=client('webauthn.get',opts),auth=authData(opts.flags??5,1),signature=sign('sha256',Buffer.concat([auth,hash(data)]),privateKey);return {id:b64(id),rawId:b64(id),type:'public-key',clientExtensionResults:{},response:{clientDataJSON:b64(data),authenticatorData:b64(auth),signature:b64(signature),userHandle:null}}}
const base={expectedChallenge:challenge,expectedOrigin:origin,expectedRPID:rpID,requireUserVerification:true};
const credential={id:b64(id),publicKey:new Uint8Array(cose),counter:0,transports:['internal']};
test('verifies a valid registration with device user verification',async()=>assert.equal((await verifyRegistrationResponse({...base,response:registration()})).verified,true));
test('verifies a valid signed transaction assertion',async()=>assert.equal((await verifyAuthenticationResponse({...base,credential,response:assertion()})).verified,true));
test('rejects wrong origin, wrong challenge, missing verification and stale counter',async()=>{for(const opts of [{origin:'https://attacker.example'},{challenge:b64(randomBytes(32))},{flags:1}])await assert.rejects(()=>verifyAuthenticationResponse({...base,credential,response:assertion(opts)}));await assert.rejects(()=>verifyAuthenticationResponse({...base,credential:{...credential,counter:1},response:assertion()}));});
test('rejects a modified signed response',async()=>{const response=assertion();const bytes=Buffer.from(response.response.signature,'base64url');bytes[bytes.length-1]^=1;response.response.signature=b64(bytes);const result=await verifyAuthenticationResponse({...base,credential,response});assert.equal(result.verified,false)});
