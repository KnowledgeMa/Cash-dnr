begin;
-- Public numbers are separate from immutable UUID identities and transaction snapshots.
create sequence public.dnr_number_seq as bigint minvalue 1000000000 maxvalue 9999999999 no cycle;
revoke all on sequence public.dnr_number_seq from public,anon,authenticated;
alter table public.profiles add column dnr_number text not null default nextval('public.dnr_number_seq')::text unique check (dnr_number ~ '^[0-9]{10}$');
create function public.prepare_dnr_send_number(p_note_id uuid,p_recipient_dnr text,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare recipient uuid; result jsonb;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_recipient_dnr is null or p_recipient_dnr !~ '^[0-9]{10}$' then raise exception 'Recipient DNR ID was not found'; end if;
 select dnr_id into recipient from public.profiles where dnr_number=p_recipient_dnr;
 if recipient is null then raise exception 'Recipient DNR ID was not found'; end if;
 result:=public.prepare_dnr_send(p_note_id,recipient,p_request_key);
 return result || jsonb_build_object('recipientDnr',p_recipient_dnr);
end; $$;
create function public.request_merchant_payment_number(p_customer_dnr text,p_references text[],p_amount integer,p_sale_reference text,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare customer uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_customer_dnr is null or p_customer_dnr !~ '^[0-9]{10}$' then raise exception 'Customer DNR ID was not found'; end if;
 select dnr_id into customer from public.profiles where dnr_number=p_customer_dnr;
 if customer is null then raise exception 'Customer DNR ID was not found'; end if;
 return public.request_merchant_payment(customer,p_references,p_amount,p_sale_reference,p_request_key);
end; $$;
revoke all on function public.prepare_dnr_send_number(uuid,text,uuid),public.request_merchant_payment_number(text,text[],integer,text,uuid) from public,anon;
grant execute on function public.prepare_dnr_send_number(uuid,text,uuid),public.request_merchant_payment_number(text,text[],integer,text,uuid) to authenticated;
CREATE OR REPLACE FUNCTION public.list_dnr_transfers()
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$;
 select coalesce(jsonb_agg(row_to_json(t)), '[]'::jsonb) from (
 select x.id,x.note_id,n.reference,n.denomination,n.status as note_status,x.sender_id,x.recipient_id,s.dnr_number as sender_dnr,r.dnr_number as recipient_dnr,s.display_name as sender_name,r.display_name as recipient_name,x.status,x.created_at,x.resolved_at,
 case when not exists(select 1 from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status) then 'setup_pending'
 when exists(select 1 from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status and e.status='failed') then 'failed'
 when (select count(*) from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status and e.status='sent')=2 then 'sent' else 'queued' end as email_status
 from public.note_transfers x join public.banknotes n on n.id=x.note_id join public.profiles s on s.id=x.sender_id join public.profiles r on r.id=x.recipient_id
 where auth.uid() is not null and (x.sender_id=auth.uid() or x.recipient_id=auth.uid()) order by x.created_at desc limit 200
 ) t;
$function$;

CREATE OR REPLACE FUNCTION public.list_merchant_payments(p_start timestamp with time zone, p_end timestamp with time zone)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$;
declare result jsonb; summary jsonb;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_start is null or p_end is null or p_end<=p_start or p_end-p_start>interval '366 days' then raise exception 'Choose a valid date range'; end if;
 select coalesce(jsonb_agg(row_to_json(t)),'[]'::jsonb) into result from (
 select p.*, (select jsonb_agg(jsonb_build_object('reference',n.reference,'denomination',n.denomination,'status',b.status) order by n.reference) from public.payment_notes n join public.banknotes b on b.id=n.note_id where n.payment_id=p.id) as notes
 from public.merchant_payments p where (p.merchant_id=auth.uid() or p.customer_id=auth.uid()) and (case when p.status='pending' then p.created_at else p.resolved_at end)>=p_start and (case when p.status='pending' then p.created_at else p.resolved_at end)<p_end order by p.created_at desc limit 200
 ) t;
 -- Reconciliation totals use completed time; pending totals use creation time.
 select jsonb_build_object('accepted_count',count(*) filter(where status='accepted'),'accepted_amount',coalesce(sum(amount) filter(where status='accepted'),0),'pending_count',count(*) filter(where status='pending'),'pending_amount',coalesce(sum(amount) filter(where status='pending'),0),'declined_count',count(*) filter(where status='declined'),'cancelled_count',count(*) filter(where status='cancelled')) into summary from public.merchant_payments where merchant_id=auth.uid() and (case when status='pending' then created_at else resolved_at end)>=p_start and (case when status='pending' then created_at else resolved_at end)<p_end;
 select coalesce(jsonb_agg(e || jsonb_build_object('merchant_dnr',m.dnr_number,'customer_dnr',c.dnr_number)),'[]'::jsonb) into result from jsonb_array_elements(result) e join public.profiles m on m.id=(e->>'merchant_id')::uuid join public.profiles c on c.id=(e->>'customer_id')::uuid;
 return jsonb_build_object('payments',result,'summary',summary,'userId',auth.uid());
end; $function$;


CREATE OR REPLACE FUNCTION public.queue_transfer_emails()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$;
declare n public.banknotes; s public.profiles; r public.profiles; recipient record; v_body text;
begin
 if TG_OP='UPDATE' and new.status=old.status then return new; end if;
 select * into n from public.banknotes where id=new.note_id;
 select * into s from public.profiles where id=new.sender_id;
 select * into r from public.profiles where id=new.recipient_id;
 v_body:='Cash DNR transaction update'||E'\n\n'||'Status: '||new.status||E'\n'||'Transaction ID: '||new.id||E'\n'||'Banknote: '||n.reference||E'\n'||'Recorded denomination: R'||n.denomination||E'\n\n'||'Sender: '||s.display_name||E'\n'||'Sender DNR ID: '||s.dnr_number||E'\n'||'Recipient: '||r.display_name||E'\n'||'Recipient DNR ID: '||r.dnr_number||E'\n\n'||'Event time (UTC): '||coalesce(new.resolved_at,new.created_at)::text||E'\n\n'||case when new.status='accepted' then 'Recorded ownership has changed to the recipient.' when new.status='pending' then 'The sender remains the recorded holder until the recipient accepts.' else 'Recorded ownership has not changed.' end||E'\n\n'||'This is a banknote record update, not an electronic money transfer.';
 for recipient in select u.id,u.email from auth.users u where u.id in (new.sender_id,new.recipient_id) and u.email is not null loop
  insert into public.transaction_emails(transfer_id,event_status,account_id,recipient_email,subject,body) values(new.id,new.status,recipient.id,recipient.email,'Cash DNR · Transfer '||new.status||' · '||n.reference,v_body) on conflict do nothing;
 end loop;
 return new;
end; $function$;

notify pgrst,'reload schema';
commit;

