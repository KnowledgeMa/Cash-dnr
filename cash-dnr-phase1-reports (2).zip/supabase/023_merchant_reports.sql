-- Merchant Reports (Phase 1). Run once after 022.
-- Adds a transaction type to payments and one read-only function that powers the
-- Reports screen: date range + status filter + reference search + paged history.
begin;

-- Every payment recorded so far is a cash-note purchase. 'digital' is reserved for the wallet phase.
alter table public.merchant_payments
 add column payment_type text not null default 'cash' check(payment_type in ('cash','digital'));

-- Helps the history screen when a merchant has many sales.
create index merchant_payments_report_idx on public.merchant_payments(merchant_id,created_at desc);

-- p_status: null/'all' | 'accepted' | 'pending' | 'rejected' (rejected = declined or cancelled)
-- p_search: sale reference, payment ID or a note reference (partial match, case-insensitive)
create function public.list_merchant_sales(
 p_start timestamptz,p_end timestamptz,
 p_status text default 'all',p_search text default null,
 p_limit integer default 10,p_offset integer default 0
) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare v_term text; v_result jsonb;
begin
 if not exists(select 1 from public.profiles where id=auth.uid() and role='merchant') then raise exception 'Merchant access required'; end if;
 if p_start is null or p_end is null or p_end<=p_start or p_end-p_start>interval '366 days' then raise exception 'Choose a valid date range'; end if;
 if coalesce(p_status,'all') not in ('all','accepted','pending','rejected') then raise exception 'Invalid status'; end if;
 if p_limit is null or p_limit not between 1 and 50 or p_offset is null or p_offset<0 then raise exception 'Invalid page'; end if;
 v_term:=nullif(trim(coalesce(p_search,'')),'');
 if v_term is not null and char_length(v_term)>80 then raise exception 'Invalid search'; end if;
 -- Escape LIKE wildcards so the merchant's text is matched literally.
 if v_term is not null then v_term:='%'||replace(replace(replace(v_term,'\','\\'),'%','\%'),'_','\_')||'%'; end if;

 with scope as (
  select p.*,(case when p.status='pending' then p.created_at else coalesce(p.resolved_at,p.created_at) end) as occurred_at
  from public.merchant_payments p
  where p.merchant_id=auth.uid()
   and (coalesce(p_status,'all')='all'
    or (p_status='accepted' and p.status='accepted')
    or (p_status='pending' and p.status='pending')
    or (p_status='rejected' and p.status in ('declined','cancelled')))
   and (v_term is null or p.sale_reference ilike v_term or p.id::text ilike v_term
    or exists(select 1 from public.payment_notes n where n.payment_id=p.id and n.reference ilike v_term))
 ), in_range as (select * from scope where occurred_at>=p_start and occurred_at<p_end),
 page as (select * from in_range order by occurred_at desc,id limit p_limit offset p_offset)
 select jsonb_build_object(
  'total',(select count(*) from in_range),
  'sales',coalesce((select jsonb_agg(jsonb_build_object(
    'id',g.id,'sale_reference',g.sale_reference,'amount',g.amount,'payment_type',g.payment_type,
    'status',case when g.status in ('declined','cancelled') then 'rejected' else g.status end,
    'detail_status',g.status,'customer_name',g.customer_name,'customer_dnr',c.dnr_number,
    'created_at',g.created_at,'resolved_at',g.resolved_at,'occurred_at',g.occurred_at,
    'notes',(select jsonb_agg(jsonb_build_object('reference',n.reference,'denomination',n.denomination) order by n.denomination desc,n.reference) from public.payment_notes n where n.payment_id=g.id)
   ) order by g.occurred_at desc,g.id) from page g join public.profiles c on c.id=g.customer_id),'[]'::jsonb)
 ) into v_result;
 return v_result;
end; $$;
revoke all on function public.list_merchant_sales(timestamptz,timestamptz,text,text,integer,integer) from public,anon;
grant execute on function public.list_merchant_sales(timestamptz,timestamptz,text,text,integer,integer) to authenticated;
commit;
