-- Run once after 016. Sender passkey approval is mandatory for all new transfers.
begin;
create table public.transfer_send_intents (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references public.profiles(id),
 note_id uuid not null references public.banknotes(id),
 recipient_dnr uuid not null,
 request_key uuid not null,
 expires_at timestamptz not null default now()+interval '5 minutes',
 transfer_id uuid unique references public.note_transfers(id),
 created_at timestamptz not null default now(),
 unique(sender_id,request_key)
);
alter table public.transfer_send_intents enable row level security;
revoke all on public.transfer_send_intents from public,anon,authenticated;
-- The verification worker validates intents through passkey_begin, never client writes.
grant select on public.transfer_send_intents to service_role;
alter table public.passkey_challenges drop constraint passkey_challenges_operation_kind_check;
alter table public.passkey_challenges add constraint passkey_challenges_operation_kind_check check(operation_kind in ('transfer','payment','transfer_send'));
alter table public.passkey_approvals drop constraint passkey_approvals_operation_kind_check;
alter table public.passkey_approvals add constraint passkey_approvals_operation_kind_check check(operation_kind in ('transfer','payment','transfer_send'));
create function public.dnr_send_capabilities() returns jsonb language sql stable security definer set search_path='' as $$ select jsonb_build_object('senderApproval',true); $$;
revoke all on function public.dnr_send_capabilities() from public,anon;
grant execute on function public.dnr_send_capabilities() to authenticated;

create function public.prepare_dnr_send(p_note_id uuid,p_recipient_dnr uuid,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); n public.banknotes; r public.profiles; i public.transfer_send_intents;
begin
 if u is null then raise exception 'Authentication required'; end if;
 if p_request_key is null or p_recipient_dnr is null then raise exception 'Invalid send details'; end if;
 if not exists(select 1 from public.dnr_passkeys where account_id=u) then raise exception 'Set up a passkey in Account first'; end if;
 perform pg_advisory_xact_lock(hashtextextended(u::text||p_request_key::text,0));
 select * into n from public.banknotes where id=p_note_id for update;
 if not found or n.current_holder is distinct from u then raise exception 'Only the current holder can transfer this note'; end if;
 if n.status<>'active' then raise exception 'Only active notes can be transferred'; end if;
 if exists(select 1 from public.note_reservations where note_id=n.id) then raise exception 'This note is reserved for another transaction'; end if;
 select * into r from public.profiles where dnr_id=p_recipient_dnr and role in ('individual','merchant');
 if not found then raise exception 'Recipient DNR ID was not found'; end if;
 if r.id=u then raise exception 'Choose another account as recipient'; end if;
 select * into i from public.transfer_send_intents where sender_id=u and request_key=p_request_key;
 if found then
  if i.note_id is distinct from p_note_id or i.recipient_dnr is distinct from p_recipient_dnr then raise exception 'Request key already used'; end if;
  if i.transfer_id is not null or i.expires_at<=now() then raise exception 'Send review expired or note unavailable'; end if;
 else
  delete from public.transfer_send_intents where sender_id=u and transfer_id is null and expires_at<now()-interval '1 day';
  insert into public.transfer_send_intents(sender_id,note_id,recipient_dnr,request_key) values(u,p_note_id,p_recipient_dnr,p_request_key) returning * into i;
 end if;
 return jsonb_build_object('intentId',i.id,'reference',n.reference,'denomination',n.denomination,'recipientDnr',r.dnr_id,'recipientName',r.display_name,'expiresAt',i.expires_at);
end; $$;
revoke all on function public.prepare_dnr_send(uuid,uuid,uuid) from public,anon;
grant execute on function public.prepare_dnr_send(uuid,uuid,uuid) to authenticated;

-- Remove the old direct-RPC route: every new request needs a sender-bound proof.
alter function public.request_dnr_transfer(uuid,uuid,uuid) rename to request_dnr_transfer_internal;
revoke all on function public.request_dnr_transfer_internal(uuid,uuid,uuid) from public,anon,authenticated;
create function public.request_dnr_transfer(p_note_id uuid,p_recipient_dnr uuid,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$ begin raise exception 'Use the secure send review'; end; $$;
revoke all on function public.request_dnr_transfer(uuid,uuid,uuid) from public,anon;
grant execute on function public.request_dnr_transfer(uuid,uuid,uuid) to authenticated;

create function public.send_dnr_transfer(p_intent_id uuid,p_approval_id uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); i public.transfer_send_intents; nid uuid; n public.banknotes; result jsonb;
begin
 if u is null then raise exception 'Authentication required'; end if;
 select note_id into nid from public.transfer_send_intents where id=p_intent_id and sender_id=u;
 if not found then raise exception 'Send review expired or note unavailable'; end if;
 -- Match the existing note-first transaction lock order.
 select * into n from public.banknotes where id=nid for update;
 select * into i from public.transfer_send_intents where id=p_intent_id and sender_id=u for update;
 if i.transfer_id is not null then
  return (select jsonb_build_object('id',id,'status',status) from public.note_transfers where id=i.transfer_id);
 end if;
 if i.expires_at<=now() then raise exception 'Send review expired or note unavailable'; end if;
 if not exists(select 1 from public.dnr_passkeys where account_id=u) then raise exception 'Set up a passkey in Account first'; end if;
 if n.current_holder is distinct from u then raise exception 'Only the current holder can transfer this note'; end if;
 if n.status<>'active' then raise exception 'Only active notes can be transferred'; end if;
 if exists(select 1 from public.note_reservations where note_id=nid) then raise exception 'This note is reserved for another transaction'; end if;
 perform public.consume_passkey_approval('transfer_send',i.id,p_approval_id);
 result:=public.request_dnr_transfer_internal(i.note_id,i.recipient_dnr,i.request_key);
 update public.transfer_send_intents set transfer_id=(result->>'id')::uuid where id=i.id;
 return result;
end; $$;
revoke all on function public.send_dnr_transfer(uuid,uuid) from public,anon;
grant execute on function public.send_dnr_transfer(uuid,uuid) to authenticated;
create or replace function public.passkey_begin(p_user uuid,p_purpose text,p_challenge text,p_kind text default null,p_operation uuid default null) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_id uuid;
begin
 if p_challenge is null or char_length(p_challenge) not between 32 and 200 then raise exception 'Invalid challenge'; end if;
 perform 1 from public.profiles where id=p_user for update;
 if not found then raise exception 'Account not found'; end if;
 delete from public.passkey_challenges where account_id=p_user and expires_at<now()-interval '1 day';
 if (select count(*) from public.passkey_challenges where account_id=p_user and expires_at>now() and used_at is null)>=5 then raise exception 'Too many approval attempts. Wait five minutes.'; end if;
 if p_purpose='register' then
  if exists(select 1 from public.dnr_passkeys where account_id=p_user) then raise exception 'A passkey is already registered'; end if;
 elsif p_purpose='authenticate' then
  if not exists(select 1 from public.dnr_passkeys where account_id=p_user) then raise exception 'Set up a passkey in Account first'; end if;
  if p_kind='transfer_send' then
   if not exists(select 1 from public.transfer_send_intents i join public.banknotes n on n.id=i.note_id where i.id=p_operation and i.sender_id=p_user and i.transfer_id is null and i.expires_at>now() and n.current_holder=p_user and n.status='active') then raise exception 'Send review expired or note unavailable'; end if;
  elsif p_kind='transfer' then
   if not exists(select 1 from public.note_transfers where id=p_operation and recipient_id=p_user and status='pending') then raise exception 'Transfer is not awaiting your acceptance'; end if;
  elsif p_kind='payment' then
   if not exists(select 1 from public.merchant_payments where id=p_operation and customer_id=p_user and status='pending') then raise exception 'Payment is not awaiting your approval'; end if;
  else raise exception 'Invalid operation'; end if;
 else raise exception 'Invalid purpose'; end if;
 insert into public.passkey_challenges(account_id,purpose,challenge,operation_kind,operation_id) values(p_user,p_purpose,p_challenge,p_kind,p_operation) returning id into v_id;
 return v_id;
end; $$;

commit;
