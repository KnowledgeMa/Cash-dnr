begin;
create table public.account_events (
 id uuid primary key default gen_random_uuid(),
 account_id uuid not null references public.profiles(id),
 event_type text not null,
 created_at timestamptz not null default now()
);
alter table public.account_events enable row level security;
revoke all on public.account_events from anon,authenticated;
grant select on public.account_events to authenticated;
create policy own_events_read on public.account_events for select to authenticated using(account_id=auth.uid());
create function public.record_profile_event() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.account_events(account_id,event_type) values(new.id,case when TG_OP='INSERT' then 'account_created' else 'profile_updated' end);
 return new;
end; $$;
revoke all on function public.record_profile_event() from public;
create trigger profile_event after insert or update of display_name,business_name on public.profiles for each row execute procedure public.record_profile_event();
create function public.update_own_profile(p_name text,p_business text default null) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_name is null or char_length(trim(p_name)) not between 2 and 80 then raise exception 'Invalid name'; end if;
 if exists(select 1 from public.profiles where id=auth.uid() and role='merchant') and (p_business is null or char_length(trim(p_business)) not between 2 and 100) then raise exception 'Invalid business name'; end if;
 update public.profiles set display_name=trim(p_name),business_name=case when role='merchant' then trim(p_business) else null end where id=auth.uid();
 if not found then raise exception 'Profile not found'; end if;
end; $$;
revoke all on function public.update_own_profile(text,text) from public,anon;
grant execute on function public.update_own_profile(text,text) to authenticated;
insert into public.account_events(account_id,event_type,created_at) select id,'account_created',created_at from public.profiles;
commit;
