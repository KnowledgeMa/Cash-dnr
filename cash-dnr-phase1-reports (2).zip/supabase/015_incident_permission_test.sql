-- Run after 014. All fixture changes roll back; no real note is restricted.
begin;
do $$
declare c uuid;cd uuid;m uuid;md uuid;a uuid;n1 uuid;n2 uuid;i uuid;p uuid;t uuid;proof uuid;key uuid:=gen_random_uuid();ref1 text:='TEST-'||upper(replace(gen_random_uuid()::text,'-',''));ref2 text:='TEST-'||upper(replace(gen_random_uuid()::text,'-',''));v jsonb;
begin
 select id,dnr_id into c,cd from public.profiles where role='individual' limit 1;
 select id,dnr_id into m,md from public.profiles where role='merchant' limit 1;
 select id into a from public.profiles where role='admin' limit 1;
 if c is null or m is null or a is null then raise exception 'Individual, merchant and admin accounts required';end if;
 insert into public.banknotes(reference,denomination,submitted_by,current_holder,status,request_key) values(ref1,200,c,c,'active',gen_random_uuid()) returning id into n1;
 insert into public.banknotes(reference,denomination,submitted_by,current_holder,status,request_key) values(ref2,100,c,c,'active',gen_random_uuid()) returning id into n2;
 perform set_config('request.jwt.claim.sub',m::text,true);execute 'set local role authenticated';
 begin perform public.report_dnr_incident(n1,'lost','Fixture reason',key);raise exception 'FAIL: nonholder report';exception when raise_exception then if SQLERRM<>'Only the current holder can report this note' then raise;end if;end;
 v:=public.request_merchant_payment(cd,array[ref1,ref2],300,'INCIDENT TEST',gen_random_uuid());p:=(v->>'id')::uuid;
 execute 'reset role';perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';
 v:=public.report_dnr_incident(n1,'lost','Fixture lost report',key);i:=(v->>'id')::uuid;
 if (public.report_dnr_incident(n1,'lost','Fixture lost report',key)->>'id')::uuid<>i then raise exception 'FAIL: repeated report';end if;
 if not exists(select 1 from public.banknotes where id=n1 and status='lost' and current_holder=c) then raise exception 'FAIL: restriction or holder';end if;
 if public.lookup_dnr_note(ref1)->>'status'<>'lost' then raise exception 'FAIL: restricted lookup';end if;
 begin update public.banknotes set status='active' where id=n1;raise exception 'FAIL: direct unflag';exception when insufficient_privilege then null;end;
 begin perform public.request_dnr_transfer(n1,md,gen_random_uuid());raise exception 'FAIL: restricted transfer request';exception when raise_exception then if SQLERRM<>'Only active notes can be transferred' then raise;end if;end;
 execute 'reset role';
 insert into public.passkey_approvals(account_id,operation_kind,operation_id) values(c,'payment',p) returning id into proof;
 execute 'set local role authenticated';
 begin perform public.resolve_merchant_payment(p,'accept',proof);raise exception 'FAIL: restricted pending payment';exception when raise_exception then if SQLERRM<>'One or more notes are unavailable' then raise;end if;end;
 execute 'reset role';
 if exists(select 1 from public.banknotes where id in(n1,n2) and current_holder<>c) or exists(select 1 from public.note_history where payment_id=p) then raise exception 'FAIL: partial payment';end if;
 if exists(select 1 from public.passkey_approvals where id=proof and consumed_at is not null) then raise exception 'FAIL: failed payment consumed proof';end if;
 perform set_config('request.jwt.claim.sub',m::text,true);execute 'set local role authenticated';
 if exists(select 1 from public.note_incidents where id=i) then raise exception 'FAIL: report reason disclosure';end if;
 begin perform public.review_dnr_recovery(i,'restore','Fixture review');raise exception 'FAIL: nonadmin restore';exception when raise_exception then if SQLERRM<>'Administrator access required' then raise;end if;end;
 execute 'reset role';perform set_config('request.jwt.claim.sub',a::text,true);execute 'set local role authenticated';
 begin perform public.review_dnr_recovery(i,'restore','Fixture review');raise exception 'FAIL: restore without holder request';exception when raise_exception then if SQLERRM<>'This report is not awaiting recovery review' then raise;end if;end;
 execute 'reset role';perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';
 perform public.request_dnr_recovery(i,'Fixture note recovered');perform public.request_dnr_recovery(i,'Fixture note recovered');
 execute 'reset role';
 if (select count(*) from public.note_incident_events where incident_id=i and event_type='recovery_requested')<>1 then raise exception 'FAIL: recovery replay';end if;
 perform set_config('request.jwt.claim.sub',a::text,true);execute 'set local role authenticated';
 perform public.review_dnr_recovery(i,'reject','Fixture insufficient evidence');
 execute 'reset role';
 if not exists(select 1 from public.banknotes where id=n1 and status='lost' and current_holder=c) then raise exception 'FAIL: rejected recovery changed note';end if;
 perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';perform public.request_dnr_recovery(i,'Fixture further recovery details');
 -- Decline the pending request to release its reservations without changing ownership.
 perform public.resolve_merchant_payment(p,'decline');execute 'reset role';
 perform set_config('request.jwt.claim.sub',a::text,true);execute 'set local role authenticated';perform public.review_dnr_recovery(i,'restore','Fixture recovery approved');execute 'reset role';
 if not exists(select 1 from public.banknotes where id=n1 and status='active' and current_holder=c) then raise exception 'FAIL: admin restoration';end if;
 -- A stolen report blocks acceptance of a transfer that was already pending.
 perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';
 v:=public.request_dnr_transfer(n1,md,gen_random_uuid());t:=(v->>'id')::uuid;
 perform public.report_dnr_incident(n1,'stolen','Fixture stolen report',gen_random_uuid());execute 'reset role';
 insert into public.passkey_approvals(account_id,operation_kind,operation_id) values(m,'transfer',t) returning id into proof;
 perform set_config('request.jwt.claim.sub',m::text,true);execute 'set local role authenticated';
 begin perform public.resolve_dnr_transfer(t,'accept',proof);raise exception 'FAIL: restricted pending transfer';exception when raise_exception then if SQLERRM<>'The note is no longer available for transfer' then raise;end if;end;
 perform public.resolve_dnr_transfer(t,'decline');execute 'reset role';
 if not exists(select 1 from public.banknotes where id=n1 and status='stolen' and current_holder=c) then raise exception 'FAIL: stolen holder';end if;
 if (select count(*) from public.note_audit where note_id=n1 and event_type='note_reported_lost')<>1 then raise exception 'FAIL: repeated report audit';end if;
end;$$;
select 'PASS: holder-only reports, privacy, lookup, transfer/payment blocks, atomic failure, recovery review and immutable holder' as result;
rollback;
