-- Run once after 003. Transfers change recorded ownership only on acceptance.
begin;
create table public.note_transfers (
 id uuid primary key default gen_random_uuid(),
 note_id uuid not null references public.banknotes(id),
 sender_id uuid not null references public.profiles(id),
 recipient_id uuid not null references public.profiles(id),
 status text not null default 'pending' check(status in ('pending','accepted','declined','cancelled')),
 request_key uuid not null,
 created_at timestamptz not null default now(),
 resolved_at timestamptz,
 check(sender_id<>recipient_id),
 unique(sender_id,request_key)
);
create unique index one_pending_transfer on public.note_transfers(note_id) where status='pending';
create index transfers_recipient on public.note_transfers(recipient_id,created_at);
alter table public.note_transfers enable row level security;
revoke all on public.note_transfers from anon,authenticated;
grant select on public.note_transfers to authenticated;
create policy transfers_read on public.note_transfers for select to authenticated using(sender_id=auth.uid() or recipient_id=auth.uid() or public.dnr_is_admin());
alter table public.note_history drop constraint note_history_event_type_check;
alter table public.note_history add constraint note_history_event_type_check check(event_type in ('registration_approved','transfer_accepted'));
alter table public.note_history drop constraint note_history_note_id_event_type_key;
create unique index one_registration_history on public.note_history(note_id) where event_type='registration_approved';
alter table public.note_history add column transfer_id uuid unique references public.note_transfers(id);
alter table public.note_audit drop constraint note_audit_event_type_check;
alter table public.note_audit add constraint note_audit_event_type_check check(event_type in ('registration_submitted','duplicate_flagged','registration_approved','registration_rejected','transfer_requested','transfer_accepted','transfer_declined','transfer_cancelled'));

create function public.request_dnr_transfer(p_note_id uuid,p_recipient_dnr uuid,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_user uuid:=auth.uid(); v_note public.banknotes; v_recipient uuid; v_transfer public.note_transfers; v_id uuid;
begin
 if v_user is null then raise exception 'Authentication required'; end if;
 if p_request_key is null then raise exception 'Invalid request identifier'; end if;
 perform pg_advisory_xact_lock(hashtextextended(v_user::text||p_request_key::text,0));
 select * into v_transfer from public.note_transfers where sender_id=v_user and request_key=p_request_key;
 if found then
  select id into v_recipient from public.profiles where dnr_id=p_recipient_dnr;
  if v_transfer.note_id is distinct from p_note_id or v_transfer.recipient_id is distinct from v_recipient then raise exception 'Request key already used'; end if;
  return jsonb_build_object('id',v_transfer.id,'status',v_transfer.status);
 end if;
 select * into v_note from public.banknotes where id=p_note_id for update;
 if not found or v_note.current_holder is distinct from v_user then raise exception 'Only the current holder can transfer this note'; end if;
 if v_note.status<>'active' then raise exception 'Only active notes can be transferred'; end if;
 if exists(select 1 from public.note_transfers where note_id=p_note_id and status='pending') then raise exception 'This note already has a pending transfer'; end if;
 select id into v_recipient from public.profiles where dnr_id=p_recipient_dnr and role in ('individual','merchant');
 if v_recipient is null then raise exception 'Recipient DNR ID was not found'; end if;
 if v_recipient=v_user then raise exception 'Choose another account as recipient'; end if;
 insert into public.note_transfers(note_id,sender_id,recipient_id,request_key) values(p_note_id,v_user,v_recipient,p_request_key) returning id into v_id;
 insert into public.note_audit(note_id,actor_id,event_type) values(p_note_id,v_user,'transfer_requested');
 return jsonb_build_object('id',v_id,'status','pending');
end; $$;

create function public.resolve_dnr_transfer(p_transfer_id uuid,p_decision text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_user uuid:=auth.uid(); v_transfer public.note_transfers; v_note public.banknotes; v_note_id uuid; v_status text;
begin
 if v_user is null then raise exception 'Authentication required'; end if;
 if p_decision is null or p_decision not in ('accept','decline','cancel') then raise exception 'Invalid transfer decision'; end if;
 -- Lock the note first in every transfer operation to avoid lock-order inversion.
 select note_id into v_note_id from public.note_transfers where id=p_transfer_id and (sender_id=v_user or recipient_id=v_user);
 if not found then raise exception 'Transfer not found'; end if;
 select * into v_note from public.banknotes where id=v_note_id for update;
 select * into v_transfer from public.note_transfers where id=p_transfer_id for update;
 if (p_decision='cancel' and v_transfer.sender_id<>v_user) or (p_decision in ('accept','decline') and v_transfer.recipient_id<>v_user) then raise exception 'You cannot perform this transfer action'; end if;
 v_status:=case p_decision when 'accept' then 'accepted' when 'decline' then 'declined' else 'cancelled' end;
 if v_transfer.status=v_status then return jsonb_build_object('status',v_status); end if;
 if v_transfer.status<>'pending' then raise exception 'This transfer has already been resolved'; end if;
 if p_decision='accept' then
  if v_note.status<>'active' or v_note.current_holder is distinct from v_transfer.sender_id then raise exception 'The note is no longer available for transfer'; end if;
  update public.banknotes set current_holder=v_transfer.recipient_id where id=v_note.id;
  insert into public.note_history(note_id,event_type,from_holder,to_holder,actor_id,transfer_id) values(v_note.id,'transfer_accepted',v_transfer.sender_id,v_transfer.recipient_id,v_user,v_transfer.id);
 end if;
 update public.note_transfers set status=v_status,resolved_at=now() where id=p_transfer_id;
 insert into public.note_audit(note_id,actor_id,event_type) values(v_note.id,v_user,'transfer_'||v_status);
 return jsonb_build_object('status',v_status);
end; $$;

create function public.list_dnr_transfers() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(row_to_json(t)), '[]'::jsonb) from (
 select x.id,x.note_id,n.reference,n.denomination,x.sender_id,x.recipient_id,s.dnr_id as sender_dnr,r.dnr_id as recipient_dnr,x.status,x.created_at,x.resolved_at
 from public.note_transfers x join public.banknotes n on n.id=x.note_id join public.profiles s on s.id=x.sender_id join public.profiles r on r.id=x.recipient_id
 where auth.uid() is not null and (x.sender_id=auth.uid() or x.recipient_id=auth.uid()) order by x.created_at desc limit 200
 ) t;
$$;
revoke all on function public.request_dnr_transfer(uuid,uuid,uuid),public.resolve_dnr_transfer(uuid,text),public.list_dnr_transfers() from public,anon;
grant execute on function public.request_dnr_transfer(uuid,uuid,uuid),public.resolve_dnr_transfer(uuid,text),public.list_dnr_transfers() to authenticated;
commit;
