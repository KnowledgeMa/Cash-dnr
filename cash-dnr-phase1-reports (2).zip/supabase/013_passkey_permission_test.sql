-- Run after 012. Rollback-only: no real passkey or payment is created.
begin;
do $$
declare c uuid;cd uuid;m uuid;md uuid;n uuid;t uuid;challenge uuid;approval uuid;v jsonb;credential text:='TEST-KEY-'||gen_random_uuid();
begin
 select id,dnr_id into c,cd from public.profiles where role='individual' and not exists(select 1 from public.dnr_passkeys where account_id=profiles.id) limit 1;
 select id,dnr_id into m,md from public.profiles where role='merchant' limit 1;
 if c is null or m is null then raise exception 'An individual without a passkey and a merchant account are required';end if;
 insert into public.banknotes(reference,denomination,submitted_by,current_holder,status,request_key) values('TEST-'||upper(replace(gen_random_uuid()::text,'-','')),200,m,m,'active',gen_random_uuid()) returning id into n;
 perform set_config('request.jwt.claim.sub',m::text,true);execute 'set local role authenticated';
 v:=public.request_dnr_transfer(n,cd,gen_random_uuid());
 execute 'reset role';
 if v is null then raise exception 'FAIL: request fixture';end if;
 t:=(v->>'id')::uuid;
 execute 'set local role service_role';
 challenge:=public.passkey_begin(c,'register',repeat('a',43));
 perform public.passkey_finish_registration(c,challenge,credential,'test-public-key',0,'[]');
 execute 'reset role';perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';
 if not (public.passkey_status()->>'enabled')::boolean then raise exception 'FAIL: enrollment status';end if;
 begin perform 1 from public.dnr_passkeys;raise exception 'FAIL: private credential disclosure';exception when insufficient_privilege then null;end;
 begin perform public.passkey_finish_authentication(c,challenge,credential,0);raise exception 'FAIL: client forged verification';exception when insufficient_privilege then null;end;
 begin perform public.resolve_dnr_transfer_internal(t,'accept');raise exception 'FAIL: internal RPC bypass';exception when insufficient_privilege then null;end;
 begin perform public.resolve_dnr_transfer(t,'accept');raise exception 'FAIL: missing proof';exception when raise_exception then if SQLERRM<>'Fresh passkey approval required' then raise;end if;end;
 execute 'reset role';execute 'set local role service_role';
 challenge:=public.passkey_begin(c,'authenticate',repeat('b',43),'transfer',t);
 approval:=public.passkey_finish_authentication(c,challenge,credential,0);
 begin perform public.passkey_finish_authentication(c,challenge,credential,0);raise exception 'FAIL: challenge replay';exception when raise_exception then if SQLERRM<>'Approval expired or already used' then raise;end if;end;
 execute 'reset role';execute 'set local role authenticated';
 begin perform public.resolve_dnr_transfer(gen_random_uuid(),'accept',approval);raise exception 'FAIL: wrong transaction proof';exception when raise_exception then if SQLERRM<>'Fresh passkey approval required' then raise;end if;end;
 perform public.resolve_dnr_transfer(t,'accept',approval);
 begin perform public.resolve_dnr_transfer(t,'accept',approval);raise exception 'FAIL: approval replay';exception when raise_exception then if SQLERRM<>'Fresh passkey approval required' then raise;end if;end;
 execute 'reset role';
 if not exists(select 1 from public.banknotes where id=n and current_holder=c) then raise exception 'FAIL: verified acceptance';end if;
 -- Expiry is checked at the consuming database operation.
 insert into public.passkey_approvals(account_id,operation_kind,operation_id,expires_at) values(c,'transfer',t,now()-interval '1 second') returning id into approval;
 execute 'set local role authenticated';
 begin perform public.resolve_dnr_transfer(t,'accept',approval);raise exception 'FAIL: expired proof';exception when raise_exception then if SQLERRM<>'Fresh passkey approval required' then raise;end if;end;
 execute 'reset role';
end; $$;
select 'PASS: private keys, trusted verification, no RPC bypass, transaction binding, expiry and replay protection' as result;
rollback;
