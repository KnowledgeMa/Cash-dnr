-- Run once after 012. Restrictions apply inside Cash DNR only.
begin;
create table public.note_incidents (
 id uuid primary key default gen_random_uuid(),note_id uuid not null references public.banknotes(id),
 reporter_id uuid not null references public.profiles(id),kind text not null check(kind in ('lost','stolen')),
 reason text not null check(char_length(reason) between 5 and 300),request_key uuid not null,
 created_at timestamptz not null default now(),resolved_at timestamptz,resolved_by uuid references public.profiles(id),
 recovery_requested_at timestamptz,recovery_reason text,last_review_reason text,
 unique(reporter_id,request_key)
);
create unique index one_open_note_incident on public.note_incidents(note_id) where resolved_at is null;
create table public.note_incident_events (
 id uuid primary key default gen_random_uuid(),incident_id uuid not null references public.note_incidents(id),
 actor_id uuid not null references public.profiles(id),event_type text not null,reason text not null,created_at timestamptz not null default now()
);
alter table public.note_incidents enable row level security;
alter table public.note_incident_events enable row level security;
revoke all on public.note_incidents,public.note_incident_events from anon,authenticated;
grant select on public.note_incidents,public.note_incident_events to authenticated;
create policy incidents_read on public.note_incidents for select to authenticated using(reporter_id=auth.uid() or public.dnr_is_admin());
create policy incident_events_read on public.note_incident_events for select to authenticated using(exists(select 1 from public.note_incidents i where i.id=incident_id and (i.reporter_id=auth.uid() or public.dnr_is_admin())));
alter table public.note_audit drop constraint note_audit_event_type_check;
alter table public.note_audit add constraint note_audit_event_type_check check(event_type in ('registration_submitted','duplicate_flagged','registration_approved','registration_rejected','transfer_requested','transfer_accepted','transfer_declined','transfer_cancelled','payment_requested','payment_accepted','payment_declined','payment_cancelled','note_reported_lost','note_reported_stolen','note_recovery_requested','note_recovery_rejected','note_restored'));
create function public.report_dnr_incident(p_note_id uuid,p_kind text,p_reason text,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare n public.banknotes;i public.note_incidents;v_id uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required';end if;
 if p_kind is null or p_kind not in ('lost','stolen') or p_reason is null or char_length(trim(p_reason)) not between 5 and 300 or p_request_key is null then raise exception 'Enter a reason of 5 to 300 characters';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text||p_request_key::text,0));
 select * into i from public.note_incidents where reporter_id=auth.uid() and request_key=p_request_key;
 if found then
  if i.note_id is distinct from p_note_id or i.kind<>p_kind or i.reason<>trim(p_reason) then raise exception 'Request key already used';end if;
  return jsonb_build_object('result','reported','id',i.id);
 end if;
 select * into n from public.banknotes where id=p_note_id for update;
 if not found or n.current_holder is distinct from auth.uid() then raise exception 'Only the current holder can report this note';end if;
 if n.status<>'active' then raise exception 'This note is already restricted or not active';end if;
 insert into public.note_incidents(note_id,reporter_id,kind,reason,request_key) values(n.id,auth.uid(),p_kind,trim(p_reason),p_request_key) returning id into v_id;
 update public.banknotes set status=p_kind where id=n.id;
 insert into public.note_incident_events(incident_id,actor_id,event_type,reason) values(v_id,auth.uid(),'reported_'||p_kind,trim(p_reason));
 insert into public.note_audit(note_id,actor_id,event_type) values(n.id,auth.uid(),'note_reported_'||p_kind);
 return jsonb_build_object('result','reported','id',v_id);
end; $$;
create function public.request_dnr_recovery(p_incident_id uuid,p_reason text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare i public.note_incidents;n public.banknotes;v_note uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required';end if;
 if p_reason is null or char_length(trim(p_reason)) not between 5 and 300 then raise exception 'Enter a reason of 5 to 300 characters';end if;
 select note_id into v_note from public.note_incidents where id=p_incident_id and reporter_id=auth.uid();
 if not found then raise exception 'Incident not found';end if;
 select * into n from public.banknotes where id=v_note for update;
 select * into i from public.note_incidents where id=p_incident_id for update;
 if i.resolved_at is not null or n.current_holder is distinct from auth.uid() or n.status<>i.kind then raise exception 'This report is not awaiting recovery';end if;
 if i.recovery_requested_at is not null then return jsonb_build_object('result','requested');end if;
 update public.note_incidents set recovery_requested_at=now(),recovery_reason=trim(p_reason) where id=i.id;
 insert into public.note_incident_events(incident_id,actor_id,event_type,reason) values(i.id,auth.uid(),'recovery_requested',trim(p_reason));
 insert into public.note_audit(note_id,actor_id,event_type) values(n.id,auth.uid(),'note_recovery_requested');
 return jsonb_build_object('result','requested');
end; $$;
create function public.review_dnr_recovery(p_incident_id uuid,p_decision text,p_reason text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare i public.note_incidents;n public.banknotes;v_note uuid;
begin
 if not public.dnr_is_admin() then raise exception 'Administrator access required';end if;
 if p_decision is null or p_decision not in ('restore','reject') or p_reason is null or char_length(trim(p_reason)) not between 5 and 300 then raise exception 'Enter a reason of 5 to 300 characters';end if;
 select note_id into v_note from public.note_incidents where id=p_incident_id;
 if not found then raise exception 'Incident not found';end if;
 select * into n from public.banknotes where id=v_note for update;
 select * into i from public.note_incidents where id=p_incident_id for update;
 if i.resolved_at is not null or i.recovery_requested_at is null or n.status<>i.kind or n.current_holder is distinct from i.reporter_id then raise exception 'This report is not awaiting recovery review';end if;
 if p_decision='restore' then
  update public.banknotes set status='active' where id=n.id;
  update public.note_incidents set resolved_at=now(),resolved_by=auth.uid(),last_review_reason=trim(p_reason) where id=i.id;
 else update public.note_incidents set recovery_requested_at=null,recovery_reason=null,last_review_reason=trim(p_reason) where id=i.id;
 end if;
 insert into public.note_incident_events(incident_id,actor_id,event_type,reason) values(i.id,auth.uid(),case when p_decision='restore' then 'restored' else 'recovery_rejected' end,trim(p_reason));
 insert into public.note_audit(note_id,actor_id,event_type) values(n.id,auth.uid(),case when p_decision='restore' then 'note_restored' else 'note_recovery_rejected' end);
 return jsonb_build_object('result',case when p_decision='restore' then 'restored' else 'rejected' end);
end; $$;
revoke all on function public.report_dnr_incident(uuid,text,text,uuid),public.request_dnr_recovery(uuid,text),public.review_dnr_recovery(uuid,text,text) from public,anon;
grant execute on function public.report_dnr_incident(uuid,text,text,uuid),public.request_dnr_recovery(uuid,text),public.review_dnr_recovery(uuid,text,text) to authenticated;
create or replace function public.list_dnr_transfers() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(row_to_json(t)), '[]'::jsonb) from (
 select x.id,x.note_id,n.reference,n.denomination,n.status as note_status,x.sender_id,x.recipient_id,s.dnr_id as sender_dnr,r.dnr_id as recipient_dnr,s.display_name as sender_name,r.display_name as recipient_name,x.status,x.created_at,x.resolved_at,
 case when not exists(select 1 from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status) then 'setup_pending'
 when exists(select 1 from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status and e.status='failed') then 'failed'
 when (select count(*) from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status and e.status='sent')=2 then 'sent' else 'queued' end as email_status
 from public.note_transfers x join public.banknotes n on n.id=x.note_id join public.profiles s on s.id=x.sender_id join public.profiles r on r.id=x.recipient_id
 where auth.uid() is not null and (x.sender_id=auth.uid() or x.recipient_id=auth.uid()) order by x.created_at desc limit 200
 ) t;
$$;

create or replace function public.list_merchant_payments(p_start timestamptz,p_end timestamptz) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare result jsonb; summary jsonb;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_start is null or p_end is null or p_end<=p_start or p_end-p_start>interval '366 days' then raise exception 'Choose a valid date range'; end if;
 select coalesce(jsonb_agg(row_to_json(t)),'[]'::jsonb) into result from (
 select p.*, (select jsonb_agg(jsonb_build_object('reference',n.reference,'denomination',n.denomination,'status',b.status) order by n.reference) from public.payment_notes n join public.banknotes b on b.id=n.note_id where n.payment_id=p.id) as notes
 from public.merchant_payments p where (p.merchant_id=auth.uid() or p.customer_id=auth.uid()) and (case when p.status='pending' then p.created_at else p.resolved_at end)>=p_start and (case when p.status='pending' then p.created_at else p.resolved_at end)<p_end order by p.created_at desc limit 200
 ) t;
 -- Reconciliation totals use completed time; pending totals use creation time.
 select jsonb_build_object('accepted_count',count(*) filter(where status='accepted'),'accepted_amount',coalesce(sum(amount) filter(where status='accepted'),0),'pending_count',count(*) filter(where status='pending'),'pending_amount',coalesce(sum(amount) filter(where status='pending'),0),'declined_count',count(*) filter(where status='declined'),'cancelled_count',count(*) filter(where status='cancelled')) into summary from public.merchant_payments where merchant_id=auth.uid() and (case when status='pending' then created_at else resolved_at end)>=p_start and (case when status='pending' then created_at else resolved_at end)<p_end;
 return jsonb_build_object('payments',result,'summary',summary,'userId',auth.uid());
end; $$;

commit;
