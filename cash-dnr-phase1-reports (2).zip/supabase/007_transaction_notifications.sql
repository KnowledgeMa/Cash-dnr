-- Run once after 005. No historical emails are sent automatically.
begin;
create table public.transaction_emails (
 id uuid primary key default gen_random_uuid(),
 transfer_id uuid not null references public.note_transfers(id),
 event_status text not null,
 account_id uuid not null references public.profiles(id),
 recipient_email text not null,
 subject text not null,
 body text not null,
 status text not null default 'pending' check(status in ('pending','processing','sent','failed')),
 attempts integer not null default 0,
 first_attempt_at timestamptz,
 next_attempt_at timestamptz not null default now(),
 lease_token uuid,
 provider_id text,
 last_error text,
 created_at timestamptz not null default now(),
 sent_at timestamptz,
 unique(transfer_id,event_status,account_id)
);
alter table public.transaction_emails enable row level security;
revoke all on public.transaction_emails from public,anon,authenticated;
grant all on public.transaction_emails to service_role;
create index transaction_emails_ready on public.transaction_emails(status,next_attempt_at);

create function public.queue_transfer_emails() returns trigger language plpgsql security definer set search_path='' as $$
declare n public.banknotes; s public.profiles; r public.profiles; recipient record; v_body text;
begin
 if TG_OP='UPDATE' and new.status=old.status then return new; end if;
 select * into n from public.banknotes where id=new.note_id;
 select * into s from public.profiles where id=new.sender_id;
 select * into r from public.profiles where id=new.recipient_id;
 v_body:='Cash DNR transaction update'||E'\n\n'||'Status: '||new.status||E'\n'||'Transaction ID: '||new.id||E'\n'||'Banknote: '||n.reference||E'\n'||'Recorded denomination: R'||n.denomination||E'\n\n'||'Sender: '||s.display_name||E'\n'||'Sender DNR ID: '||s.dnr_id||E'\n'||'Recipient: '||r.display_name||E'\n'||'Recipient DNR ID: '||r.dnr_id||E'\n\n'||'Event time (UTC): '||coalesce(new.resolved_at,new.created_at)::text||E'\n\n'||case when new.status='accepted' then 'Recorded ownership has changed to the recipient.' when new.status='pending' then 'The sender remains the recorded holder until the recipient accepts.' else 'Recorded ownership has not changed.' end||E'\n\n'||'This is a banknote record update, not an electronic money transfer.';
 for recipient in select u.id,u.email from auth.users u where u.id in (new.sender_id,new.recipient_id) and u.email is not null loop
  insert into public.transaction_emails(transfer_id,event_status,account_id,recipient_email,subject,body) values(new.id,new.status,recipient.id,recipient.email,'Cash DNR · Transfer '||new.status||' · '||n.reference,v_body) on conflict do nothing;
 end loop;
 return new;
end; $$;
revoke all on function public.queue_transfer_emails() from public,anon,authenticated;
create trigger transfer_email_queue after insert or update of status on public.note_transfers for each row execute function public.queue_transfer_emails();

create function public.claim_transaction_emails() returns setof public.transaction_emails language plpgsql security definer set search_path='' as $$
begin
 -- Stop ambiguous retries before the provider's 24-hour idempotency window expires.
 update public.transaction_emails set status='failed',last_error='Retry window expired; inspect provider logs before manual retry' where status in ('pending','processing') and (first_attempt_at<now()-interval '23 hours' or (attempts>=5 and next_attempt_at<=now()));
 return query with ready as (
 select id from public.transaction_emails where status in ('pending','processing') and next_attempt_at<=now() and attempts<5 order by created_at for update skip locked limit 5
 ) update public.transaction_emails e set status='processing',attempts=e.attempts+1,first_attempt_at=coalesce(e.first_attempt_at,now()),next_attempt_at=now()+interval '5 minutes',lease_token=gen_random_uuid() from ready where e.id=ready.id returning e.*;
end; $$;
create function public.finish_transaction_email(p_id uuid,p_lease uuid,p_provider_id text,p_error text) returns void language plpgsql security definer set search_path='' as $$
begin
 update public.transaction_emails set status=case when p_provider_id is not null then 'sent' when attempts>=5 then 'failed' else 'pending' end,provider_id=p_provider_id,sent_at=case when p_provider_id is not null then now() else null end,last_error=left(p_error,200),next_attempt_at=now()+interval '1 minute',lease_token=null where id=p_id and lease_token=p_lease and status='processing';
end; $$;
revoke all on function public.claim_transaction_emails(),public.finish_transaction_email(uuid,uuid,text,text) from public,anon,authenticated;
grant execute on function public.claim_transaction_emails(),public.finish_transaction_email(uuid,uuid,text,text) to service_role;

create or replace function public.list_dnr_transfers() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(row_to_json(t)), '[]'::jsonb) from (
 select x.id,x.note_id,n.reference,n.denomination,x.sender_id,x.recipient_id,s.dnr_id as sender_dnr,r.dnr_id as recipient_dnr,s.display_name as sender_name,r.display_name as recipient_name,x.status,x.created_at,x.resolved_at,
 case when not exists(select 1 from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status) then 'setup_pending'
 when exists(select 1 from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status and e.status='failed') then 'failed'
 when (select count(*) from public.transaction_emails e where e.transfer_id=x.id and e.event_status=x.status and e.status='sent')=2 then 'sent' else 'queued' end as email_status
 from public.note_transfers x join public.banknotes n on n.id=x.note_id join public.profiles s on s.id=x.sender_id join public.profiles r on r.id=x.recipient_id
 where auth.uid() is not null and (x.sender_id=auth.uid() or x.recipient_id=auth.uid()) order by x.created_at desc limit 200
 ) t;
$$;
create function public.list_dnr_note_history() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(row_to_json(t)), '[]'::jsonb) from (
 select h.id,h.note_id,h.event_type,h.created_at,h.to_holder,r.dnr_id as to_holder_dnr,r.display_name as to_name,s.dnr_id as from_holder_dnr,s.display_name as from_name
 from public.note_history h join public.profiles r on r.id=h.to_holder left join public.profiles s on s.id=h.from_holder
 where auth.uid() is not null and (h.from_holder=auth.uid() or h.to_holder=auth.uid() or public.dnr_is_admin()) order by h.created_at desc limit 500
 ) t;
$$;
revoke all on function public.list_dnr_note_history() from public,anon;
grant execute on function public.list_dnr_note_history() to authenticated;
commit;
