-- Cash DNR banknote registry. Run once after account setup.
begin;
create function public.dnr_is_admin() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;
revoke all on function public.dnr_is_admin() from public,anon;
grant execute on function public.dnr_is_admin() to authenticated;

create table public.banknotes (
 id uuid primary key default gen_random_uuid(),
 reference text not null unique check(reference ~ '^TEST-[A-Z0-9-]{4,40}$'),
 denomination integer not null check(denomination in (10,20,50,100,200)),
 currency text not null default 'ZAR' check(currency='ZAR'),
 submitted_by uuid not null references public.profiles(id),
 current_holder uuid references public.profiles(id),
 status text not null default 'pending' check(status in ('pending','active','rejected','lost','stolen','locked')),
 request_key uuid not null,
 created_at timestamptz not null default now(),
 reviewed_at timestamptz,
 reviewed_by uuid references public.profiles(id),
 review_reason text,
 unique(submitted_by,request_key),
 check(status not in ('active','lost','stolen','locked') or current_holder is not null),
 check(status not in ('pending','rejected') or current_holder is null)
);
create table public.note_review_flags (
 id uuid primary key default gen_random_uuid(),
 note_id uuid not null references public.banknotes(id),
 reported_by uuid not null references public.profiles(id),
 request_key uuid not null,
 reason text not null default 'duplicate_reference',
 created_at timestamptz not null default now(),
 unique(reported_by,request_key)
);
create table public.note_history (
 id uuid primary key default gen_random_uuid(),
 note_id uuid not null references public.banknotes(id),
 event_type text not null check(event_type in ('registration_approved')),
 from_holder uuid references public.profiles(id),
 to_holder uuid not null references public.profiles(id),
 actor_id uuid not null references public.profiles(id),
 created_at timestamptz not null default now(),
 unique(note_id,event_type)
);
create table public.note_audit (
 id uuid primary key default gen_random_uuid(),
 note_id uuid not null references public.banknotes(id),
 actor_id uuid not null references public.profiles(id),
 event_type text not null check(event_type in ('registration_submitted','duplicate_flagged','registration_approved','registration_rejected')),
 created_at timestamptz not null default now()
);
create index banknotes_holder_idx on public.banknotes(current_holder);
create index banknotes_submitted_idx on public.banknotes(submitted_by);
create index banknotes_status_idx on public.banknotes(status,created_at);
create index note_history_note_idx on public.note_history(note_id);
create index note_audit_note_idx on public.note_audit(note_id);
alter table public.banknotes enable row level security;
alter table public.note_review_flags enable row level security;
alter table public.note_history enable row level security;
alter table public.note_audit enable row level security;
revoke all on public.banknotes,public.note_review_flags,public.note_history,public.note_audit from anon,authenticated;
grant select on public.banknotes,public.note_review_flags,public.note_history,public.note_audit to authenticated;
create policy notes_read on public.banknotes for select to authenticated using(submitted_by=auth.uid() or current_holder=auth.uid() or public.dnr_is_admin());
create policy flags_read on public.note_review_flags for select to authenticated using(public.dnr_is_admin());
create policy history_read on public.note_history for select to authenticated using(public.dnr_is_admin() or from_holder=auth.uid() or to_holder=auth.uid());
create policy audit_read on public.note_audit for select to authenticated using(public.dnr_is_admin() or actor_id=auth.uid());

create function public.register_dnr_note(p_reference text,p_denomination integer,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_user uuid:=auth.uid(); v_ref text:=upper(trim(p_reference)); v_note public.banknotes; v_id uuid;
begin
 if v_user is null or not exists(select 1 from public.profiles where id=v_user) then raise exception 'Authentication required'; end if;
 if v_ref is null or v_ref !~ '^TEST-[A-Z0-9-]{4,40}$' or p_denomination is null or p_denomination not in (10,20,50,100,200) or p_request_key is null then raise exception 'Invalid note details'; end if;
 -- Serialize repeated requests from the same account.
 perform pg_advisory_xact_lock(hashtextextended(v_user::text||p_request_key::text,0));
 select * into v_note from public.banknotes where submitted_by=v_user and request_key=p_request_key;
 if found then
  if v_note.reference<>v_ref or v_note.denomination<>p_denomination then raise exception 'Request key already used'; end if;
  return jsonb_build_object('result','submitted','id',v_note.id);
 end if;
 if exists(select 1 from public.note_review_flags where reported_by=v_user and request_key=p_request_key) then return jsonb_build_object('result','duplicate'); end if;
 insert into public.banknotes(reference,denomination,submitted_by,request_key) values(v_ref,p_denomination,v_user,p_request_key) on conflict(reference) do nothing returning id into v_id;
 if v_id is null then
  select id into v_id from public.banknotes where reference=v_ref;
  insert into public.note_review_flags(note_id,reported_by,request_key) values(v_id,v_user,p_request_key);
  insert into public.note_audit(note_id,actor_id,event_type) values(v_id,v_user,'duplicate_flagged');
  return jsonb_build_object('result','duplicate');
 end if;
 insert into public.note_audit(note_id,actor_id,event_type) values(v_id,v_user,'registration_submitted');
 return jsonb_build_object('result','submitted','id',v_id);
end; $$;

create function public.review_dnr_note(p_note_id uuid,p_decision text,p_reason text default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_note public.banknotes;
begin
 if not public.dnr_is_admin() then raise exception 'Administrator access required'; end if;
 if p_decision is null or p_decision not in ('approve','reject') then raise exception 'Invalid review decision'; end if;
 if p_reason is not null and char_length(trim(p_reason))>300 then raise exception 'Reason too long'; end if;
 if p_decision='reject' and (p_reason is null or char_length(trim(p_reason))<5) then raise exception 'Rejection requires a reason'; end if;
 select * into v_note from public.banknotes where id=p_note_id for update;
 if not found then raise exception 'Note not found'; end if;
 if v_note.status<>'pending' then raise exception 'This note has already been reviewed'; end if;
 update public.banknotes set status=case when p_decision='approve' then 'active' else 'rejected' end,current_holder=case when p_decision='approve' then submitted_by else null end,reviewed_at=now(),reviewed_by=auth.uid(),review_reason=nullif(trim(p_reason),'') where id=p_note_id;
 if p_decision='approve' then
  insert into public.note_history(note_id,event_type,to_holder,actor_id) values(p_note_id,'registration_approved',v_note.submitted_by,auth.uid());
 end if;
 insert into public.note_audit(note_id,actor_id,event_type) values(p_note_id,auth.uid(),case when p_decision='approve' then 'registration_approved' else 'registration_rejected' end);
 return jsonb_build_object('result',case when p_decision='approve' then 'approved' else 'rejected' end);
end; $$;

create function public.lookup_dnr_note(p_reference text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_note public.banknotes; v_holder uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_reference is null or upper(trim(p_reference)) !~ '^TEST-[A-Z0-9-]{4,40}$' then raise exception 'Invalid reference'; end if;
 select * into v_note from public.banknotes where reference=upper(trim(p_reference)) and status in ('active','lost','stolen','locked');
 if not found then return jsonb_build_object('found',false); end if;
 select dnr_id into v_holder from public.profiles where id=v_note.current_holder;
 return jsonb_build_object('found',true,'reference',v_note.reference,'denomination',v_note.denomination,'currency',v_note.currency,'status',v_note.status,'holder_reference','DNR · '||right(v_holder::text,8),'is_yours',v_note.current_holder=auth.uid());
end; $$;
revoke all on function public.register_dnr_note(text,integer,uuid),public.review_dnr_note(uuid,text,text),public.lookup_dnr_note(text) from public,anon;
grant execute on function public.register_dnr_note(text,integer,uuid),public.review_dnr_note(uuid,text,text),public.lookup_dnr_note(text) to authenticated;
commit;
