CREATE OR REPLACE FUNCTION public.list_dnr_note_history()
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
 select coalesce(jsonb_agg(row_to_json(t)), '[]'::jsonb) from (
 select h.id,h.note_id,h.event_type,h.created_at,h.to_holder,r.dnr_number as to_holder_dnr,r.display_name as to_name,s.dnr_number as from_holder_dnr,s.display_name as from_name
 from public.note_history h join public.profiles r on r.id=h.to_holder left join public.profiles s on s.id=h.from_holder
 where auth.uid() is not null and (h.from_holder=auth.uid() or h.to_holder=auth.uid() or public.dnr_is_admin()) order by h.created_at desc limit 500
 ) t;
$function$;

