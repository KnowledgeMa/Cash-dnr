-- Run once after 007. Exact-note merchant payments; no digital money balance.
begin;
create table public.merchant_payments (
 id uuid primary key default gen_random_uuid(),
 merchant_id uuid not null references public.profiles(id),
 customer_id uuid not null references public.profiles(id),
 merchant_name text not null, merchant_dnr uuid not null,
 customer_name text not null, customer_dnr uuid not null,
 sale_reference text not null check(char_length(sale_reference) between 2 and 80),
 amount integer not null check(amount>0 and amount<=20000),
 status text not null default 'pending' check(status in ('pending','accepted','declined','cancelled')),
 request_key uuid not null,
 created_at timestamptz not null default now(), resolved_at timestamptz,
 unique(merchant_id,request_key),check(merchant_id<>customer_id)
);
create table public.payment_notes (
 payment_id uuid not null references public.merchant_payments(id),
 note_id uuid not null references public.banknotes(id),
 reference text not null,denomination integer not null,
 primary key(payment_id,note_id)
);
-- Shared reservation prevents a note joining a payment and a transfer simultaneously.
create table public.note_reservations (
 note_id uuid primary key references public.banknotes(id),
 kind text not null check(kind in ('transfer','payment')),
 reservation_id uuid not null
);
insert into public.note_reservations select note_id,'transfer',id from public.note_transfers where status='pending';
alter table public.merchant_payments enable row level security;
alter table public.payment_notes enable row level security;
alter table public.note_reservations enable row level security;
revoke all on public.merchant_payments,public.payment_notes,public.note_reservations from anon,authenticated;
grant select on public.merchant_payments,public.payment_notes to authenticated;
create policy payments_read on public.merchant_payments for select to authenticated using(merchant_id=auth.uid() or customer_id=auth.uid() or public.dnr_is_admin());
create policy payment_notes_read on public.payment_notes for select to authenticated using(exists(select 1 from public.merchant_payments p where p.id=payment_id and (p.merchant_id=auth.uid() or p.customer_id=auth.uid() or public.dnr_is_admin())));
create function public.reserve_transfer_note() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if TG_OP='INSERT' then
  begin insert into public.note_reservations values(new.note_id,'transfer',new.id);
  exception when unique_violation then raise exception 'This note is reserved for another transaction'; end;
 elsif old.status='pending' and new.status<>'pending' then
  delete from public.note_reservations where note_id=new.note_id and kind='transfer' and reservation_id=new.id;
 end if;
 return new;
end; $$;
create trigger transfer_reservation after insert or update of status on public.note_transfers for each row execute function public.reserve_transfer_note();
revoke all on function public.reserve_transfer_note() from public,anon,authenticated;
alter table public.note_history drop constraint note_history_event_type_check;
alter table public.note_history add constraint note_history_event_type_check check(event_type in ('registration_approved','transfer_accepted','payment_accepted'));
alter table public.note_history add column payment_id uuid references public.merchant_payments(id);
create unique index one_payment_note_history on public.note_history(payment_id,note_id) where payment_id is not null;
alter table public.note_audit drop constraint note_audit_event_type_check;
alter table public.note_audit add constraint note_audit_event_type_check check(event_type in ('registration_submitted','duplicate_flagged','registration_approved','registration_rejected','transfer_requested','transfer_accepted','transfer_declined','transfer_cancelled','payment_requested','payment_accepted','payment_declined','payment_cancelled'));
create function public.request_merchant_payment(p_customer_dnr uuid,p_references text[],p_amount integer,p_sale_reference text,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare m public.profiles; c public.profiles; p public.merchant_payments; refs text[]; note public.banknotes; pid uuid; total integer:=0; found_count integer:=0;
begin
 select * into m from public.profiles where id=auth.uid() and role='merchant';
 if not found then raise exception 'Merchant access required'; end if;
 if p_request_key is null or p_amount is null or p_amount not between 1 and 20000 or p_sale_reference is null or char_length(trim(p_sale_reference)) not between 2 and 80 or p_references is null or cardinality(p_references) not between 1 and 100 then raise exception 'Invalid payment details'; end if;
 select array_agg(upper(trim(x)) order by upper(trim(x))) into refs from unnest(p_references) x;
 if exists(select 1 from unnest(refs) x where x is null or x !~ '^TEST-[A-Z0-9-]{4,40}$') or cardinality(refs)<>(select count(distinct x) from unnest(refs) x) then raise exception 'Use unique valid TEST- references'; end if;
 select * into c from public.profiles where dnr_id=p_customer_dnr and role in ('individual','merchant') and id<>m.id;
 if not found then raise exception 'Customer DNR ID was not found'; end if;
 perform pg_advisory_xact_lock(hashtextextended(m.id::text||p_request_key::text,0));
 select * into p from public.merchant_payments where merchant_id=m.id and request_key=p_request_key;
 if found then
  if p.customer_id<>c.id or p.amount<>p_amount or p.sale_reference<>trim(p_sale_reference) or refs is distinct from (select array_agg(reference order by reference) from public.payment_notes where payment_id=p.id) then raise exception 'Request key already used'; end if;
  return jsonb_build_object('id',p.id,'status',p.status);
 end if;
 -- Every operation locks notes in UUID order before changing a reservation.
 for note in select * from public.banknotes where reference=any(refs) order by id for update loop
  found_count:=found_count+1;
  if note.current_holder is distinct from c.id or note.status<>'active' or exists(select 1 from public.note_reservations where note_id=note.id) then raise exception 'One or more notes are unavailable'; end if;
  total:=total+note.denomination;
 end loop;
 if found_count<>cardinality(refs) then raise exception 'One or more notes are unavailable'; end if;
 if total<>p_amount then raise exception 'The notes must equal the requested amount'; end if;
 insert into public.merchant_payments(merchant_id,customer_id,merchant_name,merchant_dnr,customer_name,customer_dnr,sale_reference,amount,request_key) values(m.id,c.id,case when m.business_name is not null then m.business_name||' · '||m.display_name else m.display_name end,m.dnr_id,c.display_name,c.dnr_id,trim(p_sale_reference),total,p_request_key) returning id into pid;
 insert into public.payment_notes select pid,id,reference,denomination from public.banknotes where reference=any(refs);
 insert into public.note_reservations select id,'payment',pid from public.banknotes where reference=any(refs);
 insert into public.note_audit(note_id,actor_id,event_type) select note_id,m.id,'payment_requested' from public.payment_notes where payment_id=pid;
 return jsonb_build_object('id',pid,'status','pending');
end; $$;
create function public.resolve_merchant_payment(p_payment_id uuid,p_decision text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare p public.merchant_payments; note public.banknotes; v_status text; count_notes integer:=0; total integer:=0;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_decision is null or p_decision not in ('accept','decline','cancel') then raise exception 'Invalid payment decision'; end if;
 select * into p from public.merchant_payments where id=p_payment_id and (merchant_id=auth.uid() or customer_id=auth.uid());
 if not found then raise exception 'Payment not found'; end if;
 -- Same note-first order as transfer operations. Lock payment after all its notes.
 perform 1 from public.banknotes where id in(select note_id from public.payment_notes where payment_id=p.id) order by id for update;
 select * into p from public.merchant_payments where id=p_payment_id for update;
 if (p_decision='cancel' and auth.uid()<>p.merchant_id) or (p_decision in ('accept','decline') and auth.uid()<>p.customer_id) then raise exception 'You cannot perform this payment action'; end if;
 v_status:=case p_decision when 'accept' then 'accepted' when 'decline' then 'declined' else 'cancelled' end;
 if p.status=v_status then return jsonb_build_object('status',v_status); end if;
 if p.status<>'pending' then raise exception 'This payment has already been resolved'; end if;
 if p_decision='accept' then
  if not exists(select 1 from public.profiles where id=p.merchant_id and role='merchant') then raise exception 'Merchant access required'; end if;
  for note in select n.* from public.banknotes n join public.payment_notes x on x.note_id=n.id where x.payment_id=p.id loop
   if note.current_holder is distinct from p.customer_id or note.status<>'active' or not exists(select 1 from public.note_reservations where note_id=note.id and kind='payment' and reservation_id=p.id) then raise exception 'One or more notes are unavailable'; end if;
   count_notes:=count_notes+1;total:=total+note.denomination;
  end loop;
  if count_notes=0 or total<>p.amount then raise exception 'One or more notes are unavailable'; end if;
  update public.banknotes set current_holder=p.merchant_id where id in(select note_id from public.payment_notes where payment_id=p.id);
  insert into public.note_history(note_id,event_type,from_holder,to_holder,actor_id,payment_id) select note_id,'payment_accepted',p.customer_id,p.merchant_id,auth.uid(),p.id from public.payment_notes where payment_id=p.id;
 end if;
 update public.merchant_payments set status=v_status,resolved_at=now() where id=p.id;
 delete from public.note_reservations where kind='payment' and reservation_id=p.id;
 insert into public.note_audit(note_id,actor_id,event_type) select note_id,auth.uid(),'payment_'||v_status from public.payment_notes where payment_id=p.id;
 return jsonb_build_object('status',v_status);
end; $$;
create function public.list_merchant_payments(p_start timestamptz,p_end timestamptz) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare result jsonb; summary jsonb;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_start is null or p_end is null or p_end<=p_start or p_end-p_start>interval '366 days' then raise exception 'Choose a valid date range'; end if;
 select coalesce(jsonb_agg(row_to_json(t)),'[]'::jsonb) into result from (
 select p.*, (select jsonb_agg(jsonb_build_object('reference',n.reference,'denomination',n.denomination) order by n.reference) from public.payment_notes n where n.payment_id=p.id) as notes
 from public.merchant_payments p where (p.merchant_id=auth.uid() or p.customer_id=auth.uid()) and (case when p.status='pending' then p.created_at else p.resolved_at end)>=p_start and (case when p.status='pending' then p.created_at else p.resolved_at end)<p_end order by p.created_at desc limit 200
 ) t;
 -- Reconciliation totals use completed time; pending totals use creation time.
 select jsonb_build_object('accepted_count',count(*) filter(where status='accepted'),'accepted_amount',coalesce(sum(amount) filter(where status='accepted'),0),'pending_count',count(*) filter(where status='pending'),'pending_amount',coalesce(sum(amount) filter(where status='pending'),0),'declined_count',count(*) filter(where status='declined'),'cancelled_count',count(*) filter(where status='cancelled')) into summary from public.merchant_payments where merchant_id=auth.uid() and (case when status='pending' then created_at else resolved_at end)>=p_start and (case when status='pending' then created_at else resolved_at end)<p_end;
 return jsonb_build_object('payments',result,'summary',summary,'userId',auth.uid());
end; $$;
revoke all on function public.request_merchant_payment(uuid,text[],integer,text,uuid),public.resolve_merchant_payment(uuid,text),public.list_merchant_payments(timestamptz,timestamptz) from public,anon;
grant execute on function public.request_merchant_payment(uuid,text[],integer,text,uuid),public.resolve_merchant_payment(uuid,text),public.list_merchant_payments(timestamptz,timestamptz) to authenticated;
create function public.list_own_note_reservations() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(jsonb_build_object('note_id',r.note_id,'kind',r.kind)),'[]'::jsonb) from public.note_reservations r join public.banknotes n on n.id=r.note_id where n.current_holder=auth.uid();
$$;
revoke all on function public.list_own_note_reservations() from public,anon;
grant execute on function public.list_own_note_reservations() to authenticated;
commit;
