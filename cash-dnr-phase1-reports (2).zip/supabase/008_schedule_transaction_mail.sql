-- AFTER the worker is deployed and dnr_mail_dispatch_secret is stored in Vault.
-- Enable pg_cron and pg_net in Supabase Extensions first.
do $$ begin
 if not exists(select 1 from vault.decrypted_secrets where name='dnr_mail_dispatch_secret') then raise exception 'Add dnr_mail_dispatch_secret in Vault first'; end if;
 if exists(select 1 from cron.job where jobname='cash-dnr-transaction-mail') then perform cron.unschedule('cash-dnr-transaction-mail'); end if;
end $$;
select cron.schedule('cash-dnr-transaction-mail','* * * * *',$job$
 select net.http_post(
 url:='https://rldzkvlogyvhpuiferfr.supabase.co/functions/v1/transaction-mail',
 headers:=jsonb_build_object('Content-Type','application/json','x-dnr-mail-secret',(select decrypted_secret from vault.decrypted_secrets where name='dnr_mail_dispatch_secret' limit 1)),
 body:='{}'::jsonb,
 timeout_milliseconds:=120000
 );
$job$);
