-- Run after 007. Tests roll back all changes and never send mail.
begin;
do $$
declare s uuid; r uuid; rd uuid; n uuid; t uuid; job public.transaction_emails; v jsonb;
begin
 select p.id into s from public.profiles p join auth.users u on u.id=p.id where p.role='individual' and u.email is not null limit 1;
 select p.id,p.dnr_id into r,rd from public.profiles p join auth.users u on u.id=p.id where p.role='merchant' and u.email is not null limit 1;
 if s is null or r is null then raise exception 'Individual and merchant accounts with email required'; end if;
 insert into public.banknotes(reference,denomination,submitted_by,current_holder,status,request_key) values('TEST-'||upper(replace(gen_random_uuid()::text,'-','')),200,s,s,'active',gen_random_uuid()) returning id into n;
 perform set_config('request.jwt.claim.sub',s::text,true); execute 'set local role authenticated';
 v:=public.request_dnr_transfer(n,rd,gen_random_uuid()); t:=(v->>'id')::uuid;
 begin perform public.claim_transaction_emails(); raise exception 'FAIL: user claimed queue'; exception when insufficient_privilege then null; end;
 begin perform 1 from public.transaction_emails; raise exception 'FAIL: user read private email'; exception when insufficient_privilege then null; end;
 execute 'reset role';
 if (select count(*) from public.transaction_emails where transfer_id=t and event_status='pending')<>2 then raise exception 'FAIL: both parties queued'; end if;
 if exists(select 1 from public.transaction_emails where transfer_id=t and (body not like '%Sender DNR ID:%' or body not like '%Recipient DNR ID:%' or body not like '%Sender:%' or body not like '%Recipient:%')) then raise exception 'FAIL: email identity fields'; end if;
 perform set_config('request.jwt.claim.sub',r::text,true);execute 'set local role authenticated';
 perform public.resolve_dnr_transfer(t,'accept');perform public.resolve_dnr_transfer(t,'accept');
 if not exists(select 1 from jsonb_array_elements(public.list_dnr_transfers()) x where x->>'id'=t::text and x->>'recipient_name' is not null and x->>'email_status'='queued') then raise exception 'FAIL: names or queue status'; end if;
 execute 'reset role';
 if (select count(*) from public.transaction_emails where transfer_id=t and event_status='accepted')<>2 then raise exception 'FAIL: replay duplicate mail'; end if;
 -- Limit this test's claiming to its own fixture, then roll back the adjustment.
 update public.transaction_emails set next_attempt_at=now()+interval '1 day' where transfer_id<>t;
 execute 'set local role service_role';
 select * into job from public.claim_transaction_emails() limit 1;
 if job.lease_token is null then raise exception 'FAIL: lease missing'; end if;
 if exists(select 1 from public.claim_transaction_emails()) then raise exception 'FAIL: leased twice'; end if;
 perform public.finish_transaction_email(job.id,gen_random_uuid(),'wrong-lease',null);
 if not exists(select 1 from public.transaction_emails where id=job.id and status='processing') then raise exception 'FAIL: stale lease completion'; end if;
 perform public.finish_transaction_email(job.id,job.lease_token,'test-provider-id',null);
 if not exists(select 1 from public.transaction_emails where id=job.id and status='sent') then raise exception 'FAIL: provider acknowledgement'; end if;
 execute 'reset role';
end; $$;
select 'PASS: two-party mail queue, identity fields, private access, replay safety and worker leases' as result;
rollback;
