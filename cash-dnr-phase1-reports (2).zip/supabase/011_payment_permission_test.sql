-- Run AFTER 010. All test changes roll back; no physical or electronic money moves.
begin;
do $$
declare c uuid; m uuid; a uuid; cd uuid; md uuid; n1 uuid; n2 uuid; p uuid; ref1 text:='TEST-'||upper(replace(gen_random_uuid()::text,'-',''));ref2 text:='TEST-'||upper(replace(gen_random_uuid()::text,'-',''));k uuid:=gen_random_uuid();v jsonb;
begin
 select id,dnr_id into c,cd from public.profiles where role='individual' limit 1;
 select id,dnr_id into m,md from public.profiles where role='merchant' limit 1;
 select id into a from public.profiles where role='admin' limit 1;
 if c is null or m is null or a is null then raise exception 'Individual, merchant and admin required'; end if;
 insert into public.banknotes(reference,denomination,submitted_by,current_holder,status,request_key) values(ref1,200,c,c,'active',gen_random_uuid()) returning id into n1;
 insert into public.banknotes(reference,denomination,submitted_by,current_holder,status,request_key) values(ref2,100,c,c,'active',gen_random_uuid()) returning id into n2;
 perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';
 begin perform public.request_merchant_payment(md,array[ref1,ref2],300,'TEST SALE',k);raise exception 'FAIL: nonmerchant request';exception when raise_exception then if SQLERRM<>'Merchant access required' then raise;end if;end;
 execute 'reset role';perform set_config('request.jwt.claim.sub',m::text,true);execute 'set local role authenticated';
 begin perform public.request_merchant_payment(cd,array[ref1,ref2],250,'TEST SALE',k);raise exception 'FAIL: mismatched sum';exception when raise_exception then if SQLERRM<>'The notes must equal the requested amount' then raise;end if;end;
 begin perform public.request_merchant_payment(cd,array[ref1,ref1],400,'TEST SALE',k);raise exception 'FAIL: duplicate note';exception when raise_exception then if SQLERRM not in ('Use unique valid TEST- references','Use unique valid note references') then raise;end if;end;
 v:=public.request_merchant_payment(cd,array[ref1,ref2],300,'TEST SALE',k);p:=(v->>'id')::uuid;
 if (public.request_merchant_payment(cd,array[ref2,ref1],300,'TEST SALE',k)->>'id')::uuid<>p then raise exception 'FAIL: request replay';end if;
 begin perform public.resolve_merchant_payment(p,'accept');raise exception 'FAIL: merchant self-approved';exception when raise_exception then if SQLERRM<>'You cannot perform this payment action' then raise;end if;end;
 begin update public.merchant_payments set status='accepted' where id=p;raise exception 'FAIL: direct edit';exception when insufficient_privilege then null;end;
 execute 'reset role';perform set_config('request.jwt.claim.sub',a::text,true);execute 'set local role authenticated';
 begin perform public.resolve_merchant_payment(p,'accept');raise exception 'FAIL: unrelated approval';exception when raise_exception then if SQLERRM<>'Payment not found' then raise;end if;end;
 execute 'reset role';perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';
 begin perform public.request_dnr_transfer(n1,md,gen_random_uuid());raise exception 'FAIL: payment-transfer double reservation';exception when raise_exception then if SQLERRM<>'This note is reserved for another transaction' then raise;end if;end;
 execute 'reset role';
 if (select count(*) from public.note_reservations where reservation_id=p)<>2 then raise exception 'FAIL: note reservation';end if;
 if exists(select 1 from public.banknotes where id in(n1,n2) and current_holder<>c) then raise exception 'FAIL: early ownership change';end if;
 update public.banknotes set status='locked' where id=n2;
 execute 'set local role authenticated';
 begin perform public.resolve_merchant_payment(p,'accept');raise exception 'FAIL: restricted payment';exception when raise_exception then if SQLERRM<>'One or more notes are unavailable' then raise;end if;end;
 execute 'reset role';
 if exists(select 1 from public.banknotes where id in(n1,n2) and current_holder<>c) or exists(select 1 from public.note_history where payment_id=p) then raise exception 'FAIL: partial payment changed ownership';end if;
 update public.banknotes set status='active' where id=n2;
 execute 'set local role authenticated';
 perform public.resolve_merchant_payment(p,'accept');perform public.resolve_merchant_payment(p,'accept');
 execute 'reset role';
 if (select count(*) from public.banknotes where id in(n1,n2) and current_holder=m)<>2 then raise exception 'FAIL: merchant ownership';end if;
 if (select count(*) from public.note_history where payment_id=p)<>2 then raise exception 'FAIL: repeated payment history';end if;
 if exists(select 1 from public.note_reservations where reservation_id=p) then raise exception 'FAIL: reservation retained';end if;
 perform set_config('request.jwt.claim.sub',m::text,true);execute 'set local role authenticated';
 v:=public.list_merchant_payments(now()-interval '1 day',now()+interval '1 day');
 if (v->'summary'->>'accepted_amount')::integer<300 or not exists(select 1 from jsonb_array_elements(v->'payments') x where x->>'id'=p::text and jsonb_array_length(x->'notes')=2) then raise exception 'FAIL: reconciliation';end if;
 execute 'reset role';
 -- Additional fixture requests verify decline and cancellation leave ownership untouched.
 update public.banknotes set current_holder=c where id in(n1,n2);
 execute 'set local role authenticated';v:=public.request_merchant_payment(cd,array[ref1,ref2],300,'DECLINE SALE',gen_random_uuid());p:=(v->>'id')::uuid;
 execute 'reset role';perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';perform public.resolve_merchant_payment(p,'decline');execute 'reset role';
 if exists(select 1 from public.note_reservations where reservation_id=p) then raise exception 'FAIL: decline reservation';end if;
 perform set_config('request.jwt.claim.sub',m::text,true);execute 'set local role authenticated';v:=public.request_merchant_payment(cd,array[ref1,ref2],300,'CANCEL SALE',gen_random_uuid());p:=(v->>'id')::uuid;perform public.resolve_merchant_payment(p,'cancel');execute 'reset role';
 if exists(select 1 from public.note_reservations where reservation_id=p) or exists(select 1 from public.banknotes where id in(n1,n2) and current_holder<>c) then raise exception 'FAIL: cancellation';end if;
 -- Transfer reservation prevents a merchant requesting the same note.
 perform set_config('request.jwt.claim.sub',c::text,true);execute 'set local role authenticated';perform public.request_dnr_transfer(n1,md,gen_random_uuid());execute 'reset role';
 perform set_config('request.jwt.claim.sub',m::text,true);execute 'set local role authenticated';
 begin perform public.request_merchant_payment(cd,array[ref1,ref2],300,'RESERVED SALE',gen_random_uuid());raise exception 'FAIL: transfer-payment double reservation';exception when raise_exception then if SQLERRM<>'One or more notes are unavailable' then raise;end if;end;
 execute 'reset role';
end;$$;
select 'PASS: merchant/customer permissions, multi-note atomicity, sums, replay, shared reservations, decline, cancel and reconciliation' as result;
rollback;
