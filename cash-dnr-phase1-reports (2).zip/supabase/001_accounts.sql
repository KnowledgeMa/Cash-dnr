-- Run once in a new Supabase project's SQL editor. Synthetic data only.
begin;
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 dnr_id uuid not null unique default gen_random_uuid(),
 display_name text not null check(char_length(display_name) between 2 and 80),
 role text not null check(role in ('individual','merchant','admin')),
 business_name text,
 created_at timestamptz not null default now(),
 check(role <> 'merchant' or char_length(business_name) between 2 and 100)
);
alter table public.profiles enable row level security;
revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
create policy own_profile_read on public.profiles for select to authenticated using(id=auth.uid());
create function public.create_dnr_profile() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if coalesce(new.raw_user_meta_data->>'role','') not in ('individual','merchant') then raise exception 'Invalid registration role'; end if;
 insert into public.profiles(id,display_name,role,business_name) values(new.id,new.raw_user_meta_data->>'display_name',new.raw_user_meta_data->>'role',case when new.raw_user_meta_data->>'role'='merchant' then new.raw_user_meta_data->>'business_name' else null end);
 return new;
end; $$;
revoke all on function public.create_dnr_profile() from public;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.create_dnr_profile();
-- Admin roles are provisioned by a trusted database operator, never self-registration.
commit;
