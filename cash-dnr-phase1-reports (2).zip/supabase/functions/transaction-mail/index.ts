// Deploy in Supabase, not in the public app. Secrets stay in Edge Function settings.
import {deliverEmails} from './worker.ts';
Deno.serve(async(req:Request)=>{
 const secret=Deno.env.get('DNR_MAIL_DISPATCH_SECRET');
 if(req.method!=='POST')return new Response('Method not allowed',{status:405});
 if(!secret||req.headers.get('x-dnr-mail-secret')!==secret)return new Response('Unauthorized',{status:401});
 const url=Deno.env.get('SUPABASE_URL'),serviceKey=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'),apiKey=Deno.env.get('RESEND_API_KEY'),from=Deno.env.get('DNR_MAIL_FROM');
 if(!url||!serviceKey||!apiKey||!from)return Response.json({error:'Email service is not configured'},{status:503});
 try{return Response.json(await deliverEmails({url,serviceKey,apiKey,from}));}catch{return Response.json({error:'Email worker unavailable'},{status:503})}
});
