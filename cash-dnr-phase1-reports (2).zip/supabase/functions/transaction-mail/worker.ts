type Config={url:string;serviceKey:string;apiKey:string;from:string};
type Job={id:string;lease_token:string;recipient_email:string;subject:string;body:string};
export async function deliverEmails(c:Config,send:typeof fetch=fetch){
 async function rpc(name:string,body:unknown){const r=await send(c.url+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:c.serviceKey,Authorization:'Bearer '+c.serviceKey,'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('Email queue operation failed');return r;}
 const jobs=await (await rpc('claim_transaction_emails',{})).json() as Job[];let sent=0,failed=0;
 for(const j of jobs){let providerId:string|null=null,error:string|null=null;
  try{const r=await send('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+c.apiKey,'Content-Type':'application/json','Idempotency-Key':'cash-dnr-email/'+j.id},body:JSON.stringify({from:c.from,to:[j.recipient_email],subject:j.subject,text:j.body}),signal:AbortSignal.timeout(15000)});if(r.ok){const d=await r.json() as {id?:string};if(d.id)providerId=d.id;else error='Provider response did not include a message ID';}else error='Email provider returned HTTP '+r.status;
  }catch{error='Email provider timed out or was unavailable';}
  await rpc('finish_transaction_email',{p_id:j.id,p_lease:j.lease_token,p_provider_id:providerId,p_error:error});if(providerId)sent++;else failed++;
 }
 return {processed:jobs.length,sent,failed};
}
