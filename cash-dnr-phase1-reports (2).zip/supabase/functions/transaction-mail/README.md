Transaction email setup (pending external credentials)

1. Apply supabase/007_transaction_notifications.sql once. Every future transfer request, acceptance, decline and cancellation queues one separate email for each party. Existing transactions are not backfilled.
2. Configure an email provider (this worker supports Resend), verify a sender domain and create an API key permitted to send from that domain. Set a stable sender address.
3. Deploy transaction-mail in Supabase with gateway JWT verification disabled; the worker enforces its own DNR_MAIL_DISPATCH_SECRET header. Include index.ts and worker.ts. Supabase provides SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY automatically. Keep those keys entirely inside Supabase.
4. Add Edge Function secrets RESEND_API_KEY, DNR_MAIL_FROM (e.g. Cash DNR <notifications@your-verified-domain>), and DNR_MAIL_DISPATCH_SECRET (a random secret with at least 32 bytes). Do not put secrets in browser code, SQL files or Git.
5. Store the same dispatch secret in Supabase Vault as dnr_mail_dispatch_secret. Enable pg_cron and pg_net. Apply 008_schedule_transaction_mail.sql. The worker is invoked every minute.
6. Create a new transfer. Verify separate requested and accepted emails reach both test inboxes and display matching names, full DNR IDs, reference, denomination and transaction ID. Sent means provider accepted the message, not guaranteed inbox delivery. Check provider delivery/bounce logs for inbox issues.

Queue retries use database leases, bounded retries and provider idempotency. Automatic retries stop within 23 hours of the first attempt. Before manually retrying a failed/ambiguous email, inspect provider logs to avoid duplicate delivery. Changes to the sender address while jobs are in flight can conflict with the provider's idempotency body check; keep it stable.

Use an email provider for signup confirmation SMTP separately; this worker sends transaction notifications only. Test with synthetic profiles. No secret or email address is exposed through the app's transaction listing.
