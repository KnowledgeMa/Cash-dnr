import {generateRegistrationOptions,verifyRegistrationResponse,generateAuthenticationOptions,verifyAuthenticationResponse} from 'npm:@simplewebauthn/server@13.3.0';
const origin='https://cash-dnr.tverseinfo.chatgpt.site',rpID=new URL(origin).hostname;
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function encode(b:Uint8Array){return btoa(String.fromCharCode(...b)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function decode(s:string){return Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0))}
Deno.serve(async(req:Request)=>{
 if(req.method!=='POST')return Response.json({error:'Method not allowed'},{status:405});
 if(req.headers.get('origin')&&req.headers.get('origin')!==origin)return Response.json({error:'Invalid origin'},{status:403});
 const url=Deno.env.get('SUPABASE_URL'),anon=Deno.env.get('SUPABASE_ANON_KEY'),service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
 if(!url||!anon||!service)return Response.json({error:'Passkey service is not configured'},{status:503});
 const authorization=req.headers.get('authorization');if(!authorization?.startsWith('Bearer '))return Response.json({error:'Please log in again'},{status:401});
 try{
  const u=await fetch(url+'/auth/v1/user',{headers:{apikey:anon,Authorization:authorization},signal:AbortSignal.timeout(10000)});if(!u.ok)return Response.json({error:'Please log in again'},{status:401});
  const user=await u.json() as {id:string};if(!uuid.test(user.id))throw new Error('Invalid account');
  const d=await req.json() as {action:string;kind?:string;operationId?:string;challengeId?:string;response?:any};
  async function db(path:string,body?:unknown){const r=await fetch(url+'/rest/v1/'+path,{method:body===undefined?'GET':'POST',headers:{apikey:service!,Authorization:'Bearer '+service,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(10000)});if(!r.ok){const e=await r.json() as {message?:string};const safe=['A passkey is already registered','Set up a passkey in Account first','Send review expired or note unavailable','Transfer is not awaiting your acceptance','Payment is not awaiting your approval','Approval expired or already used','Too many approval attempts. Wait five minutes.'];throw new Error(safe.includes(e.message||'')?e.message:'Passkey request could not be completed');}return r.json();}
  const keys=await db('dnr_passkeys?account_id=eq.'+user.id) as {credential_id:string;public_key:string;counter:number;transports:any[]}[];
  if(d.action==='register-options'){
   const profiles=await db('profiles?id=eq.'+user.id+'&select=dnr_id,display_name') as {dnr_id:string;display_name:string}[];
   const options=await generateRegistrationOptions({rpName:'Cash DNR',rpID,userName:profiles[0]?.dnr_id||user.id,userDisplayName:profiles[0]?.display_name||'Cash DNR account',userID:new TextEncoder().encode(user.id),attestationType:'none',authenticatorSelection:{residentKey:'required',userVerification:'required'},supportedAlgorithmIDs:[-7,-257],timeout:60000});
   const id=await db('rpc/passkey_begin',{p_user:user.id,p_purpose:'register',p_challenge:options.challenge});return Response.json({options,challengeId:id});
  }
  if(d.action==='authentication-options'){
   if(!['transfer','payment','transfer_send'].includes(d.kind||'')||!uuid.test(d.operationId||''))return Response.json({error:'Invalid transaction'},{status:400});
   const options=await generateAuthenticationOptions({rpID,userVerification:'required',allowCredentials:keys.map(k=>({id:k.credential_id,transports:k.transports})),timeout:60000});
   const id=await db('rpc/passkey_begin',{p_user:user.id,p_purpose:'authenticate',p_challenge:options.challenge,p_kind:d.kind,p_operation:d.operationId});return Response.json({options,challengeId:id});
  }
  if(!uuid.test(d.challengeId||'')||!d.response)return Response.json({error:'Invalid approval response'},{status:400});
  const challenges=await db('passkey_challenges?id=eq.'+d.challengeId+'&account_id=eq.'+user.id) as {purpose:string;challenge:string;expires_at:string;used_at:string|null}[];
  const c=challenges[0];if(!c||c.used_at||new Date(c.expires_at).getTime()<=Date.now())return Response.json({error:'Approval expired or already used'},{status:400});
  if(d.action==='register-verify'&&c.purpose==='register'){
   const v=await verifyRegistrationResponse({response:d.response,expectedChallenge:c.challenge,expectedOrigin:origin,expectedRPID:rpID,requireUserVerification:true});if(!v.verified||!v.registrationInfo)throw new Error('Verification failed');
   const credential=v.registrationInfo.credential;
   await db('rpc/passkey_finish_registration',{p_user:user.id,p_id:d.challengeId,p_credential:credential.id,p_public_key:encode(credential.publicKey),p_counter:credential.counter,p_transports:credential.transports||[]});return Response.json({enabled:true});
  }
  if(d.action==='authentication-verify'&&c.purpose==='authenticate'){
   const k=keys.find(k=>k.credential_id===d.response.id);if(!k)throw new Error('Verification failed');
   const v=await verifyAuthenticationResponse({response:d.response,expectedChallenge:c.challenge,expectedOrigin:origin,expectedRPID:rpID,requireUserVerification:true,credential:{id:k.credential_id,publicKey:decode(k.public_key),counter:Number(k.counter),transports:k.transports}});if(!v.verified)throw new Error('Verification failed');
   const id=await db('rpc/passkey_finish_authentication',{p_user:user.id,p_id:d.challengeId,p_credential:k.credential_id,p_counter:v.authenticationInfo.newCounter});return Response.json({approvalId:id});
  }
  return Response.json({error:'Invalid passkey action'},{status:400});
 }catch(e){const safe=['A passkey is already registered','Set up a passkey in Account first','Send review expired or note unavailable','Transfer is not awaiting your acceptance','Payment is not awaiting your approval','Approval expired or already used','Too many approval attempts. Wait five minutes.','Passkey request could not be completed'];const message=e instanceof Error&&safe.includes(e.message)?e.message:'Passkey verification failed. Refresh and try again.';return Response.json({error:message},{status:400})}
});
