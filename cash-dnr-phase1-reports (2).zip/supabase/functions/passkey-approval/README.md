Passkey approval setup

1. Apply supabase/012_passkey_approval.sql once after merchant payments. No passkey is enabled by this migration alone. Existing accounts retain session approval until enrollment.
2. In Supabase Edge Functions, deploy a function named passkey-approval using index.ts. Turn OFF gateway JWT verification for this function as declared in config.toml. The function independently validates every bearer token against Supabase Authentication before using privileged database access.
3. SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase Edge Functions. Do not copy the service key into the browser, ChatGPT or source code. No new third-party account or domain is needed for this deployed origin.
4. Refresh Cash DNR in a full browser tab. Open Account > Transaction approval > Set up passkey. Save it on a device/password manager you will retain access to. One credential per account is supported. In-app removal, additional credentials, passkey sign-in and account recovery are not implemented yet.
5. Enrolled accounts must verify their passkey for each payment approval or incoming transfer acceptance. Decline/cancel and transfer/request initiation retain session authorization. Accounts without a passkey show session approval explicitly.
6. First test setup and an acceptance on the phone; test cancellation of the phone prompt and confirm ownership stays unchanged. A supported phone may offer fingerprint, face, PIN or another operating-system authentication method; the app does not select or collect the method.

The expected origin and relying-party ID are pinned to https://cash-dnr.tverseinfo.chatgpt.site. A later domain change requires a migration/re-enrollment strategy. Full-tab use is required; cross-origin embedded ceremonies are not enabled. Enrollment is authorized by the existing account login; first-device enrollment should happen while the user securely controls the session.

Challenges last five minutes, verified approval receipts one minute. Each challenge and receipt is single-use and account/transaction-bound. Only the service worker can enroll credentials or issue verification receipts. Database wrappers enforce the receipt for enrolled accounts, and internal transaction functions no longer accept direct authenticated RPC calls. Transaction checks still execute atomically with receipt consumption. Biometric data/device PINs are never sent to Cash DNR.

Credential recovery requires a separately designed and tested trusted process before a public launch. No weak fallback automatically disables an enrolled account's approval requirement. Verify Supabase deployment and device behavior before relying on the new feature.
