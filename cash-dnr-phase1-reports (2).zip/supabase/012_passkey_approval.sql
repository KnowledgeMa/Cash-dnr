-- Run once after 010. Cryptographic verification is performed by the private server worker.
begin;
create table public.dnr_passkeys (
 credential_id text primary key,
 account_id uuid not null references public.profiles(id),
 public_key text not null,
 counter bigint not null default 0,
 transports jsonb not null default '[]',
 created_at timestamptz not null default now()
);
create unique index one_initial_passkey on public.dnr_passkeys(account_id);
create table public.passkey_challenges (
 id uuid primary key default gen_random_uuid(),
 account_id uuid not null references public.profiles(id),
 purpose text not null check(purpose in ('register','authenticate')),
 challenge text not null,
 operation_kind text check(operation_kind in ('transfer','payment')),
 operation_id uuid,
 expires_at timestamptz not null default now()+interval '5 minutes',
 used_at timestamptz,
 created_at timestamptz not null default now(),
 check((purpose='register' and operation_kind is null and operation_id is null) or (purpose='authenticate' and operation_kind is not null and operation_id is not null))
);
create table public.passkey_approvals (
 id uuid primary key default gen_random_uuid(),account_id uuid not null references public.profiles(id),
 operation_kind text not null check(operation_kind in ('transfer','payment')),operation_id uuid not null,
 expires_at timestamptz not null default now()+interval '1 minute',consumed_at timestamptz,
 created_at timestamptz not null default now()
);
alter table public.dnr_passkeys enable row level security;
alter table public.passkey_challenges enable row level security;
alter table public.passkey_approvals enable row level security;
revoke all on public.dnr_passkeys,public.passkey_challenges,public.passkey_approvals from public,anon,authenticated;
grant all on public.dnr_passkeys,public.passkey_challenges,public.passkey_approvals to service_role;
create function public.passkey_status() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('enabled',exists(select 1 from public.dnr_passkeys where account_id=auth.uid()));
$$;
revoke all on function public.passkey_status() from public,anon;
grant execute on function public.passkey_status() to authenticated;

create function public.passkey_begin(p_user uuid,p_purpose text,p_challenge text,p_kind text default null,p_operation uuid default null) returns uuid
language plpgsql security definer set search_path='' as $$
declare v_id uuid;
begin
 if p_challenge is null or char_length(p_challenge) not between 32 and 200 then raise exception 'Invalid challenge'; end if;
 perform 1 from public.profiles where id=p_user for update;
 if not found then raise exception 'Account not found'; end if;
 delete from public.passkey_challenges where account_id=p_user and expires_at<now()-interval '1 day';
 if (select count(*) from public.passkey_challenges where account_id=p_user and expires_at>now() and used_at is null)>=5 then raise exception 'Too many approval attempts. Wait five minutes.'; end if;
 if p_purpose='register' then
  if exists(select 1 from public.dnr_passkeys where account_id=p_user) then raise exception 'A passkey is already registered'; end if;
 elsif p_purpose='authenticate' then
  if not exists(select 1 from public.dnr_passkeys where account_id=p_user) then raise exception 'Set up a passkey in Account first'; end if;
  if p_kind='transfer' then
   if not exists(select 1 from public.note_transfers where id=p_operation and recipient_id=p_user and status='pending') then raise exception 'Transfer is not awaiting your acceptance'; end if;
  elsif p_kind='payment' then
   if not exists(select 1 from public.merchant_payments where id=p_operation and customer_id=p_user and status='pending') then raise exception 'Payment is not awaiting your approval'; end if;
  else raise exception 'Invalid operation'; end if;
 else raise exception 'Invalid purpose'; end if;
 insert into public.passkey_challenges(account_id,purpose,challenge,operation_kind,operation_id) values(p_user,p_purpose,p_challenge,p_kind,p_operation) returning id into v_id;
 return v_id;
end; $$;

create function public.passkey_finish_registration(p_user uuid,p_id uuid,p_credential text,p_public_key text,p_counter bigint,p_transports jsonb) returns void
language plpgsql security definer set search_path='' as $$
declare c public.passkey_challenges;
begin
 perform 1 from public.profiles where id=p_user for update;
 select * into c from public.passkey_challenges where id=p_id and account_id=p_user for update;
 if not found or c.purpose<>'register' or c.used_at is not null or c.expires_at<=now() then raise exception 'Approval expired or already used'; end if;
 if exists(select 1 from public.dnr_passkeys where account_id=p_user) then raise exception 'A passkey is already registered'; end if;
 insert into public.dnr_passkeys(credential_id,account_id,public_key,counter,transports) values(p_credential,p_user,p_public_key,p_counter,coalesce(p_transports,'[]'));
 update public.passkey_challenges set used_at=now() where id=p_id;
 insert into public.account_events(account_id,event_type) values(p_user,'passkey_registered');
end; $$;

create function public.passkey_finish_authentication(p_user uuid,p_id uuid,p_credential text,p_counter bigint) returns uuid
language plpgsql security definer set search_path='' as $$
declare c public.passkey_challenges;k public.dnr_passkeys;result uuid;
begin
 select * into c from public.passkey_challenges where id=p_id and account_id=p_user for update;
 if not found or c.purpose<>'authenticate' or c.used_at is not null or c.expires_at<=now() then raise exception 'Approval expired or already used'; end if;
 select * into k from public.dnr_passkeys where credential_id=p_credential and account_id=p_user for update;
 if not found or p_counter<0 or (k.counter<>0 or p_counter<>0) and p_counter<=k.counter then raise exception 'Passkey verification was superseded'; end if;
 update public.dnr_passkeys set counter=p_counter where credential_id=p_credential;
 update public.passkey_challenges set used_at=now() where id=p_id;
 insert into public.passkey_approvals(account_id,operation_kind,operation_id) values(p_user,c.operation_kind,c.operation_id) returning id into result;
 return result;
end; $$;
revoke all on function public.passkey_begin(uuid,text,text,text,uuid),public.passkey_finish_registration(uuid,uuid,text,text,bigint,jsonb),public.passkey_finish_authentication(uuid,uuid,text,bigint) from public,anon,authenticated;
grant execute on function public.passkey_begin(uuid,text,text,text,uuid),public.passkey_finish_registration(uuid,uuid,text,text,bigint,jsonb),public.passkey_finish_authentication(uuid,uuid,text,bigint) to service_role;

create function public.consume_passkey_approval(p_kind text,p_operation uuid,p_approval uuid) returns void
language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.dnr_passkeys where account_id=auth.uid()) then return; end if;
 update public.passkey_approvals set consumed_at=now() where id=p_approval and account_id=auth.uid() and operation_kind=p_kind and operation_id=p_operation and consumed_at is null and expires_at>now();
 if not found then raise exception 'Fresh passkey approval required'; end if;
end; $$;
revoke all on function public.consume_passkey_approval(text,uuid,uuid) from public,anon,authenticated;
-- Close direct-RPC bypasses while preserving existing transaction checks.
alter function public.resolve_dnr_transfer(uuid,text) rename to resolve_dnr_transfer_internal;
revoke all on function public.resolve_dnr_transfer_internal(uuid,text) from public,anon,authenticated;
create function public.resolve_dnr_transfer(p_transfer_id uuid,p_decision text,p_approval_id uuid default null) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if p_decision='accept' then perform public.consume_passkey_approval('transfer',p_transfer_id,p_approval_id); end if;
 return public.resolve_dnr_transfer_internal(p_transfer_id,p_decision);
end; $$;
alter function public.resolve_merchant_payment(uuid,text) rename to resolve_merchant_payment_internal;
revoke all on function public.resolve_merchant_payment_internal(uuid,text) from public,anon,authenticated;
create function public.resolve_merchant_payment(p_payment_id uuid,p_decision text,p_approval_id uuid default null) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if p_decision='accept' then perform public.consume_passkey_approval('payment',p_payment_id,p_approval_id); end if;
 return public.resolve_merchant_payment_internal(p_payment_id,p_decision);
end; $$;
revoke all on function public.resolve_dnr_transfer(uuid,text,uuid),public.resolve_merchant_payment(uuid,text,uuid) from public,anon;
grant execute on function public.resolve_dnr_transfer(uuid,text,uuid),public.resolve_merchant_payment(uuid,text,uuid) to authenticated;
commit;
