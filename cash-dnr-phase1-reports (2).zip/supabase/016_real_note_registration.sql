-- Run once after 014. Controlled ZAR declarations; no cash authentication or funds issuance.
begin;
alter table public.banknotes add column note_kind text not null default 'test';
alter table public.banknotes add column serial_number text;
alter table public.banknotes add column banknote_series text;
alter table public.banknotes add column physically_checked_at timestamptz;
alter table public.banknotes drop constraint banknotes_reference_check;
alter table public.banknotes add constraint banknotes_identity_check check(
 (note_kind='test' and reference ~ '^TEST-[A-Z0-9-]{4,40}$' and serial_number is null and banknote_series is null and physically_checked_at is null)
 or (note_kind='real' and serial_number ~ '^[A-Z]{1,3}[0-9]{6,12}[A-Z]{0,2}$' and serial_number is not null
 and reference='ZAR-'||denomination::text||'-'||serial_number
 and banknote_series in ('mandela_2012','centenary_2018','mandela_2023') and banknote_series is not null and physically_checked_at is not null)
);
-- Conservative collision rule: a changed denomination or series must not create a second holder.
-- Legitimate serial collisions, if encountered, require a separate resolution procedure.
create unique index one_real_serial on public.banknotes(currency,serial_number) where note_kind='real';
alter table public.note_review_flags add column request_details jsonb;

create function public.dnr_registry_capabilities() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('realRegistration',true,'version',1) where auth.uid() is not null;
$$;
create function public.dnr_reference_is_valid(p_reference text) returns boolean language sql immutable set search_path='' as $$
 select coalesce(upper(trim(p_reference)) ~ '^TEST-[A-Z0-9-]{4,40}$' or upper(trim(p_reference)) ~ '^ZAR-(10|20|50|100|200)-[A-Z]{1,3}[0-9]{6,12}[A-Z]{0,2}$',false);
$$;
create function public.register_real_dnr_note(p_serial text,p_denomination integer,p_series text,p_confirmed boolean,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); sn text:=regexp_replace(upper(trim(p_serial)),'[ \t]','','g'); ref text; n public.banknotes; flag public.note_review_flags; nid uuid; details jsonb;
begin
 if u is null or not exists(select 1 from public.profiles where id=u) then raise exception 'Authentication required'; end if;
 if sn is null or sn !~ '^[A-Z]{1,3}[0-9]{6,12}[A-Z]{0,2}$' or p_denomination is null or p_denomination not in (10,20,50,100,200)
 or p_series is null or p_series not in ('mandela_2012','centenary_2018','mandela_2023') or p_confirmed is distinct from true or p_request_key is null then raise exception 'Invalid real note details'; end if;
 ref:='ZAR-'||p_denomination::text||'-'||sn;
 details:=jsonb_build_object('serial',sn,'denomination',p_denomination,'series',p_series,'confirmed',true);
 perform pg_advisory_xact_lock(hashtextextended(u::text||p_request_key::text,0));
 select * into n from public.banknotes where submitted_by=u and request_key=p_request_key;
 if found then
  if n.note_kind<>'real' or n.reference<>ref or n.banknote_series<>p_series then raise exception 'Request key already used'; end if;
  return jsonb_build_object('result','submitted','id',n.id,'reference',n.reference);
 end if;
 select * into flag from public.note_review_flags where reported_by=u and request_key=p_request_key;
 if found then
  if flag.request_details is distinct from details then raise exception 'Request key already used'; end if;
  return jsonb_build_object('result','duplicate');
 end if;
 perform pg_advisory_xact_lock(hashtextextended('ZAR:'||sn,0));
 select * into n from public.banknotes where note_kind='real' and currency='ZAR' and serial_number=sn;
 if found then
  insert into public.note_review_flags(note_id,reported_by,request_key,reason,request_details)
  values(n.id,u,p_request_key,case when n.denomination<>p_denomination or n.banknote_series<>p_series then 'real_note_details_conflict' else 'duplicate_real_serial' end,details);
  insert into public.note_audit(note_id,actor_id,event_type) values(n.id,u,'duplicate_flagged');
  return jsonb_build_object('result','duplicate');
 end if;
 insert into public.banknotes(reference,denomination,submitted_by,request_key,note_kind,serial_number,banknote_series,physically_checked_at)
 values(ref,p_denomination,u,p_request_key,'real',sn,p_series,now()) returning id into nid;
 insert into public.note_audit(note_id,actor_id,event_type) values(nid,u,'registration_submitted');
 return jsonb_build_object('result','submitted','id',nid,'reference',ref);
end; $$;

-- Keep the existing review and audit behavior. Real-note approval requires a review reason.
create or replace function public.review_dnr_note(p_note_id uuid,p_decision text,p_reason text default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare v_note public.banknotes;
begin
 if not public.dnr_is_admin() then raise exception 'Administrator access required'; end if;
 if p_decision is null or p_decision not in ('approve','reject') then raise exception 'Invalid review decision'; end if;
 if p_reason is not null and char_length(trim(p_reason))>300 then raise exception 'Reason too long'; end if;
 if p_decision='reject' and (p_reason is null or char_length(trim(p_reason))<5) then raise exception 'Rejection requires a reason'; end if;
 select * into v_note from public.banknotes where id=p_note_id for update;
 if not found then raise exception 'Note not found'; end if;
 if v_note.status<>'pending' then raise exception 'This note has already been reviewed'; end if;
 if v_note.note_kind='real' and (p_reason is null or char_length(trim(p_reason))<5) then raise exception 'Enter a real note review reason of at least 5 characters'; end if;
 update public.banknotes set status=case when p_decision='approve' then 'active' else 'rejected' end,current_holder=case when p_decision='approve' then submitted_by else null end,
 reviewed_at=now(),reviewed_by=auth.uid(),review_reason=nullif(trim(p_reason),'') where id=p_note_id;
 if p_decision='approve' then insert into public.note_history(note_id,event_type,to_holder,actor_id) values(p_note_id,'registration_approved',v_note.submitted_by,auth.uid()); end if;
 insert into public.note_audit(note_id,actor_id,event_type) values(p_note_id,auth.uid(),case when p_decision='approve' then 'registration_approved' else 'registration_rejected' end);
 return jsonb_build_object('result',case when p_decision='approve' then 'approved' else 'rejected' end);
end; $$;
create or replace function public.lookup_dnr_note(p_reference text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare n public.banknotes; holder uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if not public.dnr_reference_is_valid(p_reference) then raise exception 'Invalid reference'; end if;
 select * into n from public.banknotes where reference=upper(trim(p_reference)) and status in ('active','lost','stolen','locked');
 if not found then return jsonb_build_object('found',false); end if;
 select dnr_id into holder from public.profiles where id=n.current_holder;
 return jsonb_build_object('found',true,'reference',n.reference,'denomination',n.denomination,'currency',n.currency,'status',n.status,
 'note_kind',n.note_kind,'serial_number',n.serial_number,'banknote_series',n.banknote_series,'holder_reference','DNR · '||right(holder::text,8),'is_yours',n.current_holder=auth.uid());
end; $$;

create or replace function public.request_merchant_payment(p_customer_dnr uuid,p_references text[],p_amount integer,p_sale_reference text,p_request_key uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare m public.profiles; c public.profiles; p public.merchant_payments; refs text[]; note public.banknotes; pid uuid; total integer:=0; found_count integer:=0;
begin
 select * into m from public.profiles where id=auth.uid() and role='merchant';
 if not found then raise exception 'Merchant access required'; end if;
 if p_request_key is null or p_amount is null or p_amount not between 1 and 20000 or p_sale_reference is null or char_length(trim(p_sale_reference)) not between 2 and 80 or p_references is null or cardinality(p_references) not between 1 and 100 then raise exception 'Invalid payment details'; end if;
 select array_agg(upper(trim(x)) order by upper(trim(x))) into refs from unnest(p_references) x;
 if exists(select 1 from unnest(refs) x where not public.dnr_reference_is_valid(x)) or cardinality(refs)<>(select count(distinct x) from unnest(refs) x) then raise exception 'Use unique valid note references'; end if;
 select * into c from public.profiles where dnr_id=p_customer_dnr and role in ('individual','merchant') and id<>m.id;
 if not found then raise exception 'Customer DNR ID was not found'; end if;
 perform pg_advisory_xact_lock(hashtextextended(m.id::text||p_request_key::text,0));
 select * into p from public.merchant_payments where merchant_id=m.id and request_key=p_request_key;
 if found then
  if p.customer_id<>c.id or p.amount<>p_amount or p.sale_reference<>trim(p_sale_reference) or refs is distinct from (select array_agg(reference order by reference) from public.payment_notes where payment_id=p.id) then raise exception 'Request key already used'; end if;
  return jsonb_build_object('id',p.id,'status',p.status);
 end if;
 -- Every operation locks notes in UUID order before changing a reservation.
 for note in select * from public.banknotes where reference=any(refs) order by id for update loop
  found_count:=found_count+1;
  if note.current_holder is distinct from c.id or note.status<>'active' or exists(select 1 from public.note_reservations where note_id=note.id) then raise exception 'One or more notes are unavailable'; end if;
  total:=total+note.denomination;
 end loop;
 if found_count<>cardinality(refs) then raise exception 'One or more notes are unavailable'; end if;
 if total<>p_amount then raise exception 'The notes must equal the requested amount'; end if;
 insert into public.merchant_payments(merchant_id,customer_id,merchant_name,merchant_dnr,customer_name,customer_dnr,sale_reference,amount,request_key) values(m.id,c.id,case when m.business_name is not null then m.business_name||' · '||m.display_name else m.display_name end,m.dnr_id,c.display_name,c.dnr_id,trim(p_sale_reference),total,p_request_key) returning id into pid;
 insert into public.payment_notes select pid,id,reference,denomination from public.banknotes where reference=any(refs);
 insert into public.note_reservations select id,'payment',pid from public.banknotes where reference=any(refs);
 insert into public.note_audit(note_id,actor_id,event_type) select note_id,m.id,'payment_requested' from public.payment_notes where payment_id=pid;
 return jsonb_build_object('id',pid,'status','pending');
end; $$;

revoke all on function public.dnr_registry_capabilities(),public.dnr_reference_is_valid(text),public.register_real_dnr_note(text,integer,text,boolean,uuid) from public,anon;
grant execute on function public.dnr_registry_capabilities(),public.dnr_reference_is_valid(text),public.register_real_dnr_note(text,integer,text,boolean,uuid) to authenticated;
commit;
