-- Run AFTER 003. Every test change is rolled back.
begin;
do $$
declare
 v_user uuid; v_reviewer uuid; v_ref text:='TEST-'||upper(replace(gen_random_uuid()::text,'-',''));
 v_key uuid:=gen_random_uuid(); v_result jsonb; v_note uuid; v_other_ref text;
begin
 select id into v_user from public.profiles where role='individual' order by created_at limit 1;
 select id into v_reviewer from public.profiles where role='merchant' order by created_at limit 1;
 if v_user is null or v_reviewer is null then raise exception 'Individual and merchant accounts required'; end if;
 perform set_config('request.jwt.claim.sub',v_user::text,true);
 perform set_config('request.jwt.claims',json_build_object('sub',v_user::text,'role','authenticated')::text,true);
 execute 'set local role authenticated';
 v_result:=public.register_dnr_note(v_ref,200,v_key); v_note:=(v_result->>'id')::uuid;
 if not exists(select 1 from public.banknotes where id=v_note and status='pending' and current_holder is null) then raise exception 'FAIL: pending registration'; end if;
 v_result:=public.register_dnr_note(v_ref,200,v_key);
 if (v_result->>'id')::uuid<>v_note then raise exception 'FAIL: idempotency'; end if;
 if (select count(*) from public.banknotes where reference=v_ref)<>1 then raise exception 'FAIL: repeated registration'; end if;
 begin
  update public.banknotes set current_holder=v_user,status='active' where id=v_note;
  raise exception 'FAIL: direct ownership update allowed';
 exception when insufficient_privilege then null;
 end;
 begin
  perform public.review_dnr_note(v_note,'approve');
  raise exception 'FAIL: non-admin approval allowed';
 exception when raise_exception then
  if SQLERRM<>'Administrator access required' then raise; end if;
 end;
 execute 'reset role';
 perform set_config('request.jwt.claim.sub',v_reviewer::text,true);
 perform set_config('request.jwt.claims',json_build_object('sub',v_reviewer::text,'role','authenticated')::text,true);
 execute 'set local role authenticated';
 if exists(select 1 from public.banknotes where id=v_note) then raise exception 'FAIL: pending note privacy'; end if;
 v_result:=public.register_dnr_note(v_ref,200,gen_random_uuid());
 if v_result->>'result'<>'duplicate' then raise exception 'FAIL: duplicate protection'; end if;
 if (public.lookup_dnr_note(v_ref)->>'found')::boolean then raise exception 'FAIL: pending note lookup privacy'; end if;
 execute 'reset role';
 if not exists(select 1 from public.note_review_flags where note_id=v_note and reported_by=v_reviewer) then raise exception 'FAIL: duplicate flag'; end if;
 if not exists(select 1 from public.banknotes where id=v_note and current_holder is null and submitted_by=v_user) then raise exception 'FAIL: duplicate changed ownership'; end if;
 -- Temporary admin fixture, never committed.
 update public.profiles set role='admin' where id=v_reviewer;
 execute 'set local role authenticated';
 perform public.review_dnr_note(v_note,'approve','Automated rollback test');
 if not exists(select 1 from public.banknotes where id=v_note and status='active' and current_holder=v_user) then raise exception 'FAIL: approval'; end if;
 if (select count(*) from public.note_history where note_id=v_note)<>1 then raise exception 'FAIL: ownership history'; end if;
 if not exists(select 1 from public.note_audit where note_id=v_note and event_type='registration_approved') then raise exception 'FAIL: approval audit'; end if;
 begin
  perform public.review_dnr_note(v_note,'approve');
  raise exception 'FAIL: replayed approval allowed';
 exception when raise_exception then
  if SQLERRM<>'This note has already been reviewed' then raise; end if;
 end;
 if not (public.lookup_dnr_note(v_ref)->>'found')::boolean then raise exception 'FAIL: approved lookup'; end if;
 execute 'reset role';
end;
$$;
select 'PASS: pending privacy, duplicates, idempotency, role access, atomic approval, history and replay protection' as result;
rollback;
